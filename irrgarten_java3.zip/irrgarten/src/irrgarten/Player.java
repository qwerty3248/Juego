/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package irrgarten;
import java.util.ArrayList;
/**
 * Clase que representa a un jugador en el juego.
 *
 * @author jesus
 */
public class Player {
    private static int MAX_WEAPONS = 2;
    private static int MAX_SHIELDS = 3;
    private static int INITIAL_HEALTH = 10;
    private static int HITS2LOSE = 3;
    private String name;
    private char number;
    private float intelligence;
    private float strength;
    private float health;
    private int row;
    private int col;
    private int consecutiveHits = 0;
    private ArrayList<Weapon> weapon;
    private ArrayList<Shield> shield;

    /**
     * Constructor de la clase Player.
     *
     * @param number Número de identificación del jugador.
     * @param intelligence Nivel de inteligencia del jugador.
     * @param strength Nivel de fuerza del jugador.
     */
    public Player(char number, float intelligence, float strength) {
        this.number = number;
        this.intelligence = intelligence;
        this.strength = strength;
        name = "Player #" + number;
        health = INITIAL_HEALTH;
        weapon = new ArrayList<Weapon>(MAX_WEAPONS);
        shield = new ArrayList<Shield>(MAX_SHIELDS);
    }

    public int getRow (){
        return this.row;
    
    }
    
    public int getCol (){
        return this.col;
    
    }
    
    public char getNumber(){
    
        return this.number;
    
    }
    
    /**
     * Resucita al jugador, restaurando su salud y eliminando armas y escudos.
     */
    public void resurrect() {
        weapon.clear();
        shield.clear();
        health = INITIAL_HEALTH;
        consecutiveHits = 0;
    }

    /**
     * Establece la posición del jugador en el laberinto.
     *
     * @param rows Fila.
     * @param cols Columna.
     */
    public void setPos(int rows, int cols) {
        this.col = cols;
        this.row = rows;
    }

    /**
     * Verifica si el jugador ha muerto.
     *
     * @return `true` si el jugador ha muerto, `false` en caso contrario.
     */
    public boolean dead() {
        return (health == 0);
    }

    /**
     * Realiza un ataque, teniendo en cuenta las armas y la fuerza del jugador.
     *
     * @return Valor del ataque.
     */
    public float attack() {
        float ataque = sumWeapons();
        ataque += strength;
        return ataque;
    }

    /**
     * Defiende al jugador contra un ataque recibido.
     *
     * @param receiveAttack Valor del ataque recibido.
     * @return `true` si el jugador logra defenderse, `false` en caso contrario.
     */
    public boolean defend(float receiveAttack) {
        return manageHit(receiveAttack);
    }

    /**
     * Obtiene una representación en cadena del jugador.
     *
     * @return Cadena que representa al jugador.
     */
    @Override
    public String toString() {
        return "P[" + number + "," + health + "," + strength + "," + intelligence + "]\n";
    }

    /**
     * Crea y devuelve un nuevo arma.
     *
     * @return Nuevo objeto de tipo Weapon.
     */
    public Weapon newWeapon() {
        Weapon arma = new Weapon(Dice.weaponPower(), Dice.usesLeft());
        return arma;
    }

    /**
     * Crea y devuelve un nuevo escudo.
     *
     * @return Nuevo objeto de tipo Shield.
     */
    public Shield newShield() {
        Shield escudo = new Shield(Dice.shieldPower(), Dice.usesLeft());
        return escudo;
    }

    /**
     * Calcula la energía defensiva del jugador, teniendo en cuenta los escudos y la inteligencia.
     *
     * @return Valor de la energía defensiva.
     */
    public float defensiveEnergy() {
        float defensa = sumShields();
        defensa += intelligence;
        return defensa;
    }

    /**
     * Reinicia el contador de golpes consecutivos recibidos.
     */
    public void resetHits() {
        consecutiveHits = 0;
    }

    /**
     * Disminuye la salud del jugador al recibir un golpe.
     */
    public void gotWounded() {
        health = health - 1;
    }

    /**
     * Incrementa el contador de golpes consecutivos recibidos.
     */
    public void incConsecutiveHits() {
        consecutiveHits++;
    }

    /**
     * Calcula la suma de los ataques de las armas del jugador.
     *
     * @return Valor total de los ataques de las armas.
     */
    public float sumWeapons() {
        float ataque = 0.0f;
        for (int i = 0; i < weapon.size(); i++) {
            ataque += (weapon.get(i)).attack();
        }
        return ataque;
    }

    /**
     * Calcula la suma de las capacidades protectoras de los escudos del jugador.
     *
     * @return Valor total de las capacidades protectoras de los escudos.
     */
    public float sumShields() {
        float defensa = 0.0f;
        for (int i = 0; i < shield.size(); i++) {
            defensa = defensa + (shield.get(i)).protect();
        }
        return defensa;
    }

    /**
     * Realiza un movimiento en una dirección específica.
     *
     * @param direction Dirección del movimiento.
     * @param validMoves Lista de direcciones válidas disponibles.
     * @return Dirección del movimiento realizado.
     */
    Directions move(Directions direction, ArrayList<Directions> validMoves) {
        //throw new UnsupportedOperationException();
        int size = validMoves.size();
        boolean contained = validMoves.contains(direction);
        if (size > 0 && !(contained)){
            
            Directions firstElement = validMoves.get(0);
            return firstElement;
        
        }else{
        
            return direction;
        
        }
        
    }

    /**
     * Recibe una recompensa.
     */
    void receiveReward() {
        //throw new UnsupportedOperationException();
        int wReward = Dice.weaponsReward();
        int sReward = Dice.shieldsReward();
        
        for (int i = 1; i <= wReward; i++){
            Weapon wnew = new Weapon(Dice.weaponPower(),Dice.usesLeft());
            receiveWeapon(wnew);
        
        }
        
        for (int i = 1; i <= sReward; i++){
            
            Shield snew = new Shield(Dice.shieldPower(),Dice.usesLeft());
            receiveShield(snew);
        
        }
        
        int extraHealth = Dice.healthReward();
        
        health += extraHealth;
        
    }

    /**
     * Recibe un arma.
     *
     * @param w Arma recibida.
     */
    void receiveWeapon(Weapon w) {
        //throw new UnsupportedOperationException();
        for (int i = weapon.size()-1 ; i >= 0; i--){
            
            Weapon wi = weapon.get(i);
            boolean discard = wi.discard ();
            if (discard){
                weapon.remove(wi);
            
            }
            
        
        }
        
        int size = weapon.size();
        
        if (size < MAX_WEAPONS){
            
            weapon.add(w);
        
        }
        
        
    }

    /**
     * Recibe un escudo.
     *
     * @param s Escudo recibido.
     */
    void receiveShield(Shield s) {
        //throw new UnsupportedOperationException();
        
        for (int i = shield.size() -1 ; i >= 0; i--){
            
            Shield si = shield.get(i);
            boolean discard = si.discard ();
            if (discard){
                shield.remove(si);
            
            }
            
        
        }
        
        int size = shield.size();
        
        if (size < MAX_SHIELDS){
            
            shield.add(s);
        
        }
        
        
        
    }

    /**
     * Gestiona un golpe recibido.
     *
     * @param receivedAttack Valor del ataque recibido.
     * @return `true` si el jugador pierde, `false` en caso contrario.
     */
    boolean manageHit(float receivedAttack) {
        // throw new UnsupportedOperationException();
        float defense = defensiveEnergy();
        
        if (defense < receivedAttack){
            this.gotWounded();
            this.incConsecutiveHits();
        
        }else{
        
            this.resetHits();
        
        }
        
        boolean lose ;
        
        if (consecutiveHits == HITS2LOSE || dead()){
            
            this.resetHits();
            lose = true;
        
        }else{
            
            lose=false;
        
        }
        
        return lose;
        
        
        
    }
}
