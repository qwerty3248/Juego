/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package irrgarten;

/**
 * Clase que representa un monstruo en el juego, con la capacidad de atacar, recibir daño y
 * gestionar su posición y estado.
 *
 * @author jesus
 */
public class Monster {
    private static int INITIAL_HEALTH = 5;
    private String name;
    private float intelligence;
    private float health;
    private float strength;
    private int row;
    private int col;

    /**
     * Constructor de la clase Monster que crea un monstruo con el nombre, inteligencia y fuerza
     * especificados.
     *
     * @param name         Nombre del monstruo.
     * @param intelligence Inteligencia del monstruo.
     * @param strength     Fuerza del monstruo.
     */
    public Monster(String name, float intelligence, float strength) {
        this.name = name;
        this.intelligence = intelligence;
        this.strength = strength;
        health = INITIAL_HEALTH;
    }

    /**
     * Comprueba si el monstruo está muerto, es decir, si su salud es igual a cero.
     *
     * @return `true` si el monstruo está muerto, `false` en caso contrario.
     */
    public boolean dead() {
        return (health == 0);
    }

    /**
     * Realiza un ataque, generando una intensidad de ataque basada en la fuerza del monstruo.
     *
     * @return La intensidad del ataque del monstruo.
     */
    public float attack() {
        return Dice.intensity(strength);
    }

    /**
     * Establece la posición del monstruo en el laberinto.
     *
     * @param row Fila en la que se coloca el monstruo.
     * @param col Columna en la que se coloca el monstruo.
     */
    public void setPos(int row, int col) {
        this.row = row;
        this.col = col;
    }

    /**
     * Obtiene una representación de cadena del monstruo, que incluye su nombre, salud, fuerza e inteligencia.
     *
     * @return Representación de cadena del monstruo.
     */
    @Override
    public String toString() {
        return "M[" + name + "," + health + "," + strength + "," + intelligence + "]\n";
    }

    /**
     * Hace que el monstruo reciba un punto de daño.
     */
    public void gotWounded() {
        health = health - 1;
    }

    /**
     * Intenta defenderse de un ataque recibido.
     *
     * @param receivedAttack El valor del ataque recibido.
     * @return `true` si el monstruo se defiende con éxito, `false` en caso contrario.
     */   
    public boolean defend (float receivedAttack){
    
        //throw new UnsupportedOperationException();
        boolean isDead = dead();
        if (!isDead){
            float defensiveEnergy = Dice.intensity(intelligence);
            if (defensiveEnergy < receivedAttack){
                gotWounded();
                isDead = dead();
            }
        
        }
        
        return isDead;
              
                
    }
    
    
    
}
