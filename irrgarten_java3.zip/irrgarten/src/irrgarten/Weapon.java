/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package irrgarten;

/**
 * Clase que representa un arma en el juego.
 *
 * @author jesus
 */
public class Weapon {
    private float power;
    private int uses;

    /**
     * Constructor de la clase Weapon.
     *
     * @param power Potencia del arma.
     * @param uses Número de usos disponibles para el arma.
     */
    public Weapon(float power, int uses) {
        this.power = power;
        this.uses = uses;
    }

    /**
     * Constructor de la clase Weapon que asigna valores predeterminados.
     */
    public Weapon() {
        this.power = 5.0f;
        this.uses = 3;
    }

    /**
     * Realiza un ataque utilizando el arma.
     *
     * @return Potencia del ataque realizado con el arma.
     */
    public float attack() {
        float aux = 0.0f;
        if (uses > 0) {
            uses -= 1;
            aux = power;
        }
        return aux;
    }

    /**
     * Obtiene una representación en cadena del arma.
     *
     * @return Cadena que representa el arma.
     */
    @Override
    public String toString() {
        return "W[" + power + "," + uses + "]";
    }

    /**
     * Determina si el arma debe descartarse.
     *
     * @return `true` si el arma debe descartarse, `false` en caso contrario.
     */
    public boolean discard() {
        boolean discard = false;
        Dice dado = new Dice();
        if (dado.discardElement(uses)) {
            discard = true;
        }
        return discard;
    }
}
