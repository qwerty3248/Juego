/**
 * Clase que representa el juego en el laberinto.
 *
 * @author jesus
 */

package irrgarten;
import java.util.ArrayList;


public class Game {
    private static int MAX_ROUNDS = 10;
    private int currentPlayerIndex;
    private String log;
    private ArrayList<Monster> monsters;
    private Labyrinth labyrinth;       
    private ArrayList<Player> players;
    private Player currentPlayer;
    
    /**
     * Constructor de la clase Game.
     *
     * @param nplayers El número de jugadores en el juego.
     */
    public Game (int nplayers){
        players = new ArrayList<>(nplayers);
        for (int i = 0; i < nplayers; i++){
            players.add(new Player((char)(i+1),Dice.randomIntelligence(),Dice.randomStrength()));
        }
        currentPlayerIndex = Dice.WhoStarts(nplayers-1);
        monsters = new ArrayList<>(nplayers/2);
        labyrinth =  new Labyrinth (6,6,5,5);
        log = "";
        currentPlayer = players.get(currentPlayerIndex);
        this.configureLabyrinth();
        
    }

    public Game(int nplayers, boolean debug) {
        if (debug){
           
            players = new ArrayList<>(nplayers);
            for (int i = 0; i < nplayers; i++){
                players.add(new Player((char)(i+1),Dice.randomIntelligence(),Dice.randomStrength()));
            }
            currentPlayerIndex = Dice.WhoStarts(nplayers-1);
            monsters = new ArrayList<>(nplayers/2);
            labyrinth =  new Labyrinth (6,6,5,5);
            log = "";
            currentPlayer = players.get(currentPlayerIndex);
            this.configureLabyrinthDebug();
        
        
        }else{
        
           players = new ArrayList<>(nplayers);
        for (int i = 0; i < nplayers; i++){
            char numero = Character.forDigit(i + 1,10);
            players.add(new Player(numero,Dice.randomIntelligence(),Dice.randomStrength()));
        }
        currentPlayerIndex = Dice.WhoStarts(nplayers-1);
        monsters = new ArrayList<>(nplayers/2);
        labyrinth =  new Labyrinth (6,6,5,5);
        log = "";
        currentPlayer = players.get(currentPlayerIndex);
        this.configureLabyrinth(); 
        
        
        }
        
    }
    
    /**
     * Verifica si el juego ha terminado.
     *
     * @return `true` si el juego ha terminado, `false` en caso contrario.
     */
    public boolean finished(){
        return labyrinth.haveaWinner();
    }
    
    /**
     * Obtiene el estado actual del juego.
     *
     * @return Un objeto `GameState` que representa el estado del juego.
     */
    public GameState getGameState(){
        String jugadores = "", monstruos = "";
        for (int i = 0; i < players.size(); i++){
            jugadores += players.get(i).toString();
        }
        for (int i = 0; i < monsters.size(); i++){
            monstruos += monsters.get(i).toString();
        }
        
        GameState estado = new GameState (labyrinth.toString(),jugadores
                                          ,monstruos,currentPlayerIndex
                                          ,finished(),log);
        
        return estado;
    }
    
    /**
     * Configura el laberinto del juego, agregando jugadores y bloques.
     */
    private void configureLabyrinth(){
        for (int i = 0; i < players.size()/2; i++){
            monsters.add(new Monster(Dice.randomNom(),Dice.randomIntelligence()
                                      ,Dice.randomStrength()));
            labyrinth.addMonster(Dice.randomPos(6),
                                 Dice.randomPos(6) ,monsters.get(i) );
        }
        labyrinth.addBlock(Orientation.VERTICAL,
                           Dice.randomPos(6),
                           Dice.randomPos(6),Dice.randomPos(5));
    }
    
    private void configureLabyrinthDebug(){
        monsters.add(new Monster("PEDRO",1,1));
        labyrinth.addMonster(2,2,monsters.get(0));
        labyrinth.addBlock(Orientation.VERTICAL,
                           Dice.randomPos(6),
                           Dice.randomPos(6),Dice.randomPos(5));
    }
 
    
    /**
     * Cambia al siguiente jugador en el turno.
     */
    private void nextPlayer(){
        currentPlayerIndex++;
        if (currentPlayerIndex >= players.size()){
            currentPlayerIndex = 0;
        }
        currentPlayer = players.get(currentPlayerIndex);
    }
    
    /**
     * Registra el jugador ganador en el registro de juego.
     */
    private void logPlayerWon(){
        int aux = currentPlayerIndex +1;
        log += "El jugador "+aux+" ha ganado el combate\n";
    }
    
    /**
     * Registra el monstruo ganador en el registro de juego.
     */
    private void logMonsterWon(){
        log += "El monstruo ha ganado el combate\n";
        //no sabemos cuál
    }
    
    /**
     * Registra al jugador resucitado en el registro de juego.
     */
    private void logResurrected(){
        int aux = currentPlayerIndex +1;
        log += "El jugador "+aux+" ha resucitado\n";
    }
    
    /**
     * Registra al jugador que perdió el turno por estar muerto en el registro de juego.
     */
    private void logPlayerSkipTurn(){
        int aux = currentPlayerIndex +1;
        log += "El jugador "+aux+" ha perdido el turno por estar muerto\n";
    }
    
    /**
     * Registra al jugador que no siguió las instrucciones en el registro de juego.
     */
    private void logPlayerNoOrders(){
        int aux = currentPlayerIndex +1;
        log += "El jugador "+aux+" no ha seguido las instrucciones, tonto\n";
    }
    
    /**
     * Registra al jugador que se movió a una casilla sin nada o no pudo moverse en el registro de juego.
     */
    private void logNoMonster(){
        int aux = currentPlayerIndex +1;
        log += "El jugador "+aux+" se ha movido a una casilla sin nada o" +
                " no se ha podido mover\n";
    }
    
    /**
     * Registra el número de rondas que han transcurrido en el registro de juego.
     *
     * @param rounds Número de rondas transcurridas.
     * @param max    Número máximo de rondas en el juego.
     */
    private void logRounds(int rounds,int max){
        log+="Han pasado "+rounds+" rondas de "+max+"\n";
    }
    
/**
     * Realiza el siguiente paso en el juego.
     *
     * @param preferredDirection La dirección preferida del jugador.
     * @return `true` si el paso se realizó con éxito, `false` en caso contrario.
     */
    public boolean nextStep(Directions preferredDirection){
        //throw new UnsupportedOperationException();
        log = "";
        boolean dead = currentPlayer.dead();
        if (!dead){
        
            Directions direction = actualDirection(preferredDirection);
            if (direction != preferredDirection){
                logPlayerNoOrders();
            
            }
            Monster monster = labyrinth.putPlayer(direction, currentPlayer);
            
            if(monster == null){
                logNoMonster();
            
            }else{
                
                GameCharacter winner = combat(monster);
                manageReward(winner);
                
            }
            
        }else{
        
            manageResurrection();
        
        }
        
        boolean endGame = finished();
        
        if (!endGame){
            
            nextPlayer();
        
        }
        return endGame;
        
    }
    
    /**
     * Obtiene la dirección actual del jugador.
     *
     * @param preferredDirection La dirección preferida del jugador.
     * @return La dirección actual del jugador.
     */
    private Directions actualDirection(Directions preferredDirection){
        //throw new UnsupportedOperationException();
        int currentRow = players.get(currentPlayerIndex).getRow();
        int currentCol = players.get(currentPlayerIndex).getCol();
        
        ArrayList <Directions> validMoves = labyrinth.validMoves(currentRow, currentCol);
        
        return currentPlayer.move(preferredDirection, validMoves);
        
        
    }
    
    /**
     * Realiza un combate entre el jugador y el monstruo.
     *
     * @param monster El monstruo con el que se realiza el combate.
     * @return El personaje que ganó el combate.
     */
    private GameCharacter combat(Monster monster){
        //throw new UnsupportedOperationException();
        int rounds = 0;
        GameCharacter winner = GameCharacter.PLAYER;
        
        float playerAttack=currentPlayer.attack();
        
        boolean lose = monster.defend(playerAttack);
        
        while((!lose) && rounds < MAX_ROUNDS){
            winner = GameCharacter.MONSTER;
            rounds++;
            float monsterAttack = monster.attack();
            lose = currentPlayer.defend(monsterAttack);
            if(!lose){
                playerAttack = currentPlayer.attack();
                winner = GameCharacter.PLAYER;
                lose = monster.defend(playerAttack);
            
            }
        
        
        }
        
        logRounds(rounds,MAX_ROUNDS);
        return winner;
        
    }
    
    /**
     * Gestiona las recompensas del juego para el personaje ganador.
     *
     * @param winner El personaje ganador del juego.
     */
    private void manageReward(GameCharacter winner){
        //throw new UnsupportedOperationException();
        if (winner == GameCharacter.PLAYER){
            currentPlayer.receiveReward();
            logPlayerWon();
        
        
        }else{
        
            logMonsterWon();
        
        }
        
        
    }
    
    /**
     * Gestiona la resurrección de los jugadores en el juego.
     */
    private void manageResurrection(){
        //throw new UnsupportedOperationException();
        boolean resurrect = Dice.resurrectPlayer();
        if(resurrect){
            currentPlayer.resurrect();
            logResurrected();
        
        }else{
            logPlayerSkipTurn();
        
        }
        
        
    }
}
