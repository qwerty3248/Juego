# frozen_string_literal: true

# Módulo Orientation proporciona constantes que representan orientaciones en un juego.
module Orientation
  # Constante que representa una orientación vertical.
  VERTICAL = "VERTICAL"

  # Constante que representa una orientación horizontal.
  HORIZONTAL = "HORIZONTAL"
end

