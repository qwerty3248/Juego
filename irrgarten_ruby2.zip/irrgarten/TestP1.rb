# frozen_string_literal: true
require_relative 'dice'
require_relative 'weapon'
require_relative 'shield'
require_relative 'orientation'
require_relative 'game_character'
require_relative 'directions'
require_relative 'game_state'
require_relative 'player'
require_relative 'monster'
require_relative 'labyrinth'
require_relative 'game'
lab = "- - -"
players = "2"
monster = "1"
log = "0"

juego = GameState.new(lab,players,monster,1,false,log)
jugador = Player.new(1,2,3)
puts jugador.tostring
puts juego.labyrinthv
puts juego.log
dado = Dice.new
for x in 0..50
puts dado.resurrect_player
end
puts dado.discard_element(5)
puts dado.health_reward
puts dado.random_pos(7)

escudo = Shield.proteccion
puts escudo.tostring
puts escudo.protect

espada = Weapon.arma
puts espada.tostring
puts espada.attack

perdido = Orientation::VERTICAL
puts perdido

arriba = Directions::DOWN
puts arriba

mostro = GameCharacter::PLAYER
puts mostro






