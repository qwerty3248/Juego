# frozen_string_literal: true
require_relative 'labyrinth'
require_relative 'game_state'
require_relative 'orientation'

# Clase Game representa el juego principal.
class Game

  # Número máximo de rondas en el juego.
  @@MAX_ROUNDS = 10

  # Inicializa una nueva instancia de la clase Game.
  #
  # @param nplayers [Integer] Número de jugadores.
  def initialize(nplayers)
    @players = Array.new(nplayers)
    for i in 0..(nplayers - 1)
      @players[i] = Player.new((i + 1), Dice.new.random_intelligence, Dice.new.random_strength)
    end
    @current_player_index = Dice.new.who_starts(nplayers - 1)
    @monsters = Array.new(nplayers / 2)
    @labyrinth = Labyrinth.new(6, 6, 5, 5)
    @log = ""
    @current_player = @players[@current_player_index]
  end

  # Verifica si el juego ha terminado.
  #
  # @return [Boolean] `true` si el laberinto tiene un ganador, `false` en caso contrario.
  def finished
    @labyrinth.have_a_winner
  end

  # Obtiene el estado actual del juego.
  def get_game_state
    jugadores = ""
    monstruos = ""
    for i in 0..(@players.size - 1)
      jugadores += @players[i].to_s
    end
    for i in 0..(@monsters.size - 1)
      monstruos += @monsters[i].to_s
    end

    estado = GameState.estado(@labyrinth.to_s, jugadores, monstruos, @current_player_index, finished, @log)

    puts estado
  end

  # Configura el laberinto con monstruos y bloques.
  def configure_labyrinth
    for i in 0..(@monsters.size - 1)
      @monsters[i] = Monster.new(Dice.new.random_nom, Dice.new.random_intelligence, Dice.new.random_strength)
      @labyrinth.add_monster(Dice.new.random_pos(6), Dice.new.random_pos(6), @monsters[i])
    end
    @labyrinth.add_block(Orientation.new.VERTICAL, Dice.new.random_pos(6), Dice.new.random_pos(6), Dice.new.random_pos(5))
  end

  # Cambia al siguiente jugador en turno.
  def next_player
    @current_player_index += 1
    if @current_player_index >= @players.size
      @current_player_index = 0
    end
    @current_player = @players[@current_player_index]
  end

  # Registra al jugador ganador en el registro de juego.
  def log_player_won
    aux = @current_player_index + 1
    @log += "El jugador #{aux} ha ganado el combate\n"
  end

  # Registra al monstruo ganador en el registro de juego.
  def log_monster_won
    @log += "El monstruo #{@monsters[0].to_s} ha ganado el combate\n"
    # No sabemos cuál
  end

  # Registra al jugador resucitado en el registro de juego.
  def log_resurrected
    aux = @current_player_index + 1
    @log += "El jugador #{aux} ha resucitado\n"
  end

  # Registra al jugador que perdió el turno por estar muerto en el registro de juego.
  def log_player_skip_turn
    aux = @current_player_index + 1
    @log += "El jugador #{aux} ha perdido el turno por estar muerto\n"
  end

  # Registra al jugador que no siguió las instrucciones en el registro de juego.
  def log_player_no_orders
    aux = @current_player_index + 1
    @log += "El jugador #{aux} no ha seguido las instrucciones, tonto\n"
  end

  # Registra al jugador que se movió a una casilla sin nada o no pudo moverse en el registro de juego.
  def log_no_monster
    aux = @current_player_index + 1
    @log += "El jugador #{aux} se ha movido a una casilla sin nada o no se ha podido mover, tonto\n"
  end

  # Registra el número de rondas que han transcurrido en el registro de juego.
  #
  # @param rounds [Integer] Número de rondas transcurridas.
  # @param max [Integer] Número máximo de rondas en el juego.
  def log_rounds(rounds, max)
    @log += "Han pasado #{rounds} rondas de #{max}\n"
  end

  # Realiza el siguiente paso en el juego.
  #
  # @param preferred_direction [Directions] Dirección preferida para el movimiento.
  def next_step(preferred_direction)
    raise NotImplementedError, "Subclasses must implement the 'next_step' method."
  end

  # Obtiene la dirección actual del jugador.
  #
  # @param preferred_direction [Directions] Dirección preferida del jugador.
  # @return [Directions] La dirección actual del jugador.
  def actual_direction(preferred_direction)
    raise NotImplementedError, "Subclasses must implement the 'actual_direction' method."
  end

  # Realiza un combate con un monstruo.
  #
  # @param monster [Monster] Monstruo con el que se realiza el combate.
  # @return [GameCharacter] El personaje que ganó el combate.
  def combat(monster)
    raise NotImplementedError, "Subclasses must implement the 'combat' method."
  end

  # Gestiona las recompensas del juego para el personaje ganador.
  #
  # @param winner [GameCharacter] El personaje ganador del juego.
  def manage_reward(winner)
    raise NotImplementedError, "Subclasses must implement the 'manage_reward' method."
  end

  # Gestiona la resurrección de los personajes en el juego.
  def manage_resurrection
    raise NotImplementedError, "Subclasses must implement the 'manage_resurrection' method."
  end
end
