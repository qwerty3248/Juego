# frozen_string_literal: true

# Módulo GameCharacter proporciona constantes que representan tipos de personajes en un juego.
module GameCharacter
  # Constante que representa un jugador.
  PLAYER = "PLAYER"

  # Constante que representa un monstruo.
  MONSTER = "MONSTER"
end

