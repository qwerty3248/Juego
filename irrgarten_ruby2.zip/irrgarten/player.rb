# frozen_string_literal: true
require_relative 'dice'
require_relative 'weapon'
require_relative 'shield'
require_relative 'directions'

# Clase Player representa a un jugador del juego.
class Player

  # Tamaño máximo de armas que un jugador puede tener.
  @@MAX_WEAPONS = 2

  # Tamaño máximo de escudos que un jugador puede tener.
  @@MAX_SHIELDS = 3

  # Salud inicial del jugador.
  @@INITIAL_HEALTH = 10

  # Número de golpes consecutivos necesarios para perder.
  @@HITS2LOSE = 3

  # Inicializa una nueva instancia de la clase Player.
  #
  # @param number [Integer] Número del jugador.
  # @param intelligence [Integer] Inteligencia del jugador.
  # @param strength [Integer] Fuerza del jugador.
  def initialize(number, intelligence, strength)
    # Inicializa un array de escudos.
    @shield = Array.new(@@MAX_SHIELDS)
    # Inicializa un array de armas.
    @weapon = Array.new(@@MAX_WEAPONS)
    # Nombre del jugador.
    @name = "Player ##{number}"
    # Número del jugador.
    @number = number
    # Nivel de inteligencia del jugador.
    @intelligence = intelligence
    # Nivel de fuerza del jugador.
    @strength = strength
    # Salud del jugador.
    @health = @@INITIAL_HEALTH
    # Fila en la que se encuentra el jugador.
    @row = 0
    # Columna en la que se encuentra el jugador.
    @col = 0
    # Golpes consecutivos recibidos por el jugador.
    @consecutiveHits = 0
  end

  # Resucita al jugador, restableciendo sus atributos.
  def resurrect
    @weapon.clear
    @shield.clear
    @health = @@INITIAL_HEALTH
    @consecutiveHits = 0
  end

  # Establece la posición del jugador en el tablero.
  #
  # @param rows [Integer] Fila en el tablero.
  # @param cols [Integer] Columna en el tablero.
  def set_pos(rows, cols)
    @col = cols
    @row = rows
  end

  # Verifica si el jugador está muerto.
  #
  # @return [Boolean] `true` si el jugador está muerto, `false` en caso contrario.
  def dead
    @health == 0
  end

  # Realiza un ataque, calculando la fuerza de ataque.
  def attack
    ataque = sum_weapons
    ataque += @strength
    puts ataque
  end

  # Gestiona la defensa del jugador contra un ataque recibido.
  #
  # @param receiveAttack [Float] Valor del ataque recibido.
  def defend(receiveAttack)
    manage_hit(receiveAttack)
  end

  # Convierte el objeto Player en una cadena de texto representativa.
  def tostring
    "P[#{@name}, #{@health}, #{@strength}, #{@intelligence}]\n"
  end

  # Crea una nueva arma y muestra sus propiedades.
  def new_weapon
    arma = Weapon.new(Dice.new.weapon_power, Dice.new.uses_left)
    puts arma
  end

  # Crea un nuevo escudo y muestra sus propiedades.
  def new_shield
    escudo = Shield.new(Dice.new.shield_power, Dice.new.uses_left)
    puts escudo
  end

  # Calcula la energía defensiva del jugador.
  def defensive_energy
    defensa = sum_shields
    defensa += @intelligence
    puts defensa
  end

  # Reinicia el contador de golpes consecutivos.
  def reset_hits
    @consecutiveHits = 0
  end

  # Reduce la salud del jugador al recibir un golpe.
  def got_wounded
    @health = @health - 1
  end

  # Incrementa el contador de golpes consecutivos.
  def inc_consecutive_hits
    @consecutiveHits = @consecutiveHits + 1
  end

  # Calcula la suma de las propiedades de las armas.
  def sum_weapons
    ataque = 0.0
    for i in 0..(@weapon.size - 1)
      ataque += @weapon[i].attack
    end
    puts ataque
  end

  # Calcula la suma de las propiedades de los escudos.
  def sum_shields
    defensa = 0.0
    for i in 0..(@shield.size - 1)
      defensa = defensa + @shield[i].protect
    end
    puts defensa
  end

  # Mueve al jugador en una dirección específica.
  #
  # @param direction [Symbol] Dirección del movimiento.
  # @param valid_moves [Array<Symbol>] Lista de direcciones válidas disponibles.
  def move(direction, valid_moves)
    raise NotImplementedError, "Subclasses must implement the 'move' method."
  end

  # Recibe una recompensa.
  def receive_reward
    raise NotImplementedError, "Subclasses must implement the 'receive_reward' method."
  end

  # Recibe un arma.
  #
  # @param weapon [Weapon] Arma recibida.
  def receive_weapon(weapon)
    raise NotImplementedError, "Subclasses must implement the 'receive_weapon' method."
  end

  # Recibe un escudo.
  #
  # @param shield [Shield] Escudo recibido.
  def receive_shield(shield)
    raise NotImplementedError, "Subclasses must implement the 'receive_shield' method."
  end

  # Gestiona un golpe recibido.
  #
  # @param received_attack [Float] Valor del ataque recibido.
  # @return [Boolean] `true` si el jugador logra defenderse, `false` en caso contrario.
  def manage_hit(received_attack)
    raise NotImplementedError, "Subclasses must implement the 'manage_hit' method."
  end

end
