# frozen_string_literal: true
require_relative 'player'
require_relative 'monster'

# Clase que representa un Laberinto.
class Labyrinth
  BLOCK_CHAR = 'X'
  EMPTY_CHAR = '-'
  MONSTER_CHAR = 'M'
  COMBAT_CHAR = 'C'
  EXIT_CHAR = 'E'

  attr_reader :nRows, :nCols, :exitRow, :exitCol, :monsters, :players


  # Constructor de la clase Labyrinth.
  #
  # @param nRows [Integer] Número de filas en el laberinto.
  # @param nCols [Integer] Número de columnas en el laberinto.
  # @param exitRow [Integer] Fila de la salida del laberinto.
  # @param exitCol [Integer] Columna de la salida del laberinto.
  def initialize(nRows, nCols, exitRow, exitCol)
    @nRows = nRows
    @nCols = nCols
    @exitRow = exitRow
    @exitCol = exitCol
    @monsters = Array.new(nRows) { Array.new(nCols) }
    @players = Array.new(nRows) { Array.new(nCols) }
    @labyrinth = Array.new(nRows) { Array.new(nCols, EMPTY_CHAR) }
  end

  # Comprueba si hay un ganador en el laberinto.
  #
  # @return [Boolean] `true` si hay un ganador, `false` en caso contrario.
  def have_winner
    @players[@exitRow][@exitCol] != nil
  end

  # Genera una representación en cadena del laberinto.
  #
  # @return [String] Una cadena que representa el laberinto.
  def to_string
    labe = "Labyrinth{nRows=#{@nRows}, nCols=#{@nCols}, exitRow=#{@exitRow}, exitCol=#{@exitCol}}\n"
    rinto = ''

    for i in 0...@nRows
      for j in 0...@nCols
        rinto += @labyrinth[i][j] + ' '
      end
      rinto += "\n"
    end

    labe + rinto
  end


  # Agrega un monstruo al laberinto en una posición específica.
  #
  # @param row [Integer] Fila en la que se agrega el monstruo.
  # @param col [Integer] Columna en la que se agrega el monstruo.
  # @param monster [Monster] Monstruo a agregar.
  def add_monster(row, col, monster)
    if pos_ok(row, col) && @monsters[row][col].nil?
      @monsters[row][col] = monster
      @labyrinth[row][col] = MONSTER_CHAR
    end
  end

  # Método de marcador de posición para distribuir jugadores en el laberinto.
  #
  # @param players [Array<Player>] Lista de jugadores para distribuir en el laberinto.
  # @raise [NotImplementedError] Este método debe ser implementado en las subclases.
  def spreadPlayers(players)
    raise NotImplementedError, "Subclasses must implement the 'spreadPlayers' method."
  end

  # Método de marcador de posición para colocar un jugador en una dirección específica en el laberinto.
  #
  # @param direction [Symbol] Dirección en la que se coloca al jugador (:ARRIBA, :ABAJO, :IZQUIERDA, :DERECHA).
  # @param player [Player] Jugador a colocar en el laberinto.
  # @raise [NotImplementedError] Este método debe ser implementado en las subclases.
  def putPlayer( direction,  player)
    raise NotImplementedError, "Subclasses must implement the 'putPlayer' method."

  end

  # Método de marcador de posición para agregar un bloque al laberinto.
  #
  # @param orientation [Symbol] Orientación del bloque (:VERTICAL o :HORIZONTAL).
  # @param startRow [Integer] Fila de inicio del bloque.
  # @param startCol [Integer] Columna de inicio del bloque.
  # @param length [Integer] Longitud del bloque.
  # @raise [NotImplementedError] Este método debe ser implementado en las subclases.
  def  addBlock( orientation,  startRow, startCol, length)
    raise NotImplementedError, "Subclasses must implement the 'addBlock' method."
  end

  # Método de marcador de posición para obtener una lista de movimientos válidos desde una posición dada.
  #
  # @param row [Integer] Fila de la posición.
  # @param col [Integer] Columna de la posición.
  # @raise [NotImplementedError] Este método debe ser implementado en las subclases.
  def validMoves( row, col)
    raise NotImplementedError, "Subclasses must implement the 'validMoves' method."
  end

  private

  # Comprueba si una posición en el laberinto contiene un monstruo.
  def monster_pos(row, col)
    @labyrinth[row][col] == MONSTER_CHAR
  end

  # Comprueba si una posición en el laberinto contiene la salida.
  def exit_pos(row, col)
    @labyrinth[row][col] == EXIT_CHAR
  end

  # Comprueba si una posición en el laberinto contiene un combate.
  def combat_pos(row, col)
    @labyrinth[row][col] == COMBAT_CHAR
  end

  # Comprueba si es posible moverse a una posición en el laberinto.
  def can_step_on(row, col)
    pos_ok(row, col) && (monster_pos(row, col) || empty_pos(row, col) || exit_pos(row, col))
  end

  # Actualiza la posición anterior del jugador o monstruo en el laberinto.
  def update_old_pos(row, col)
    if pos_ok(row, col)
      @labyrinth[row][col] = COMBAT_CHAR if combat_pos(row, col)
      @labyrinth[row][col] = EMPTY_CHAR
    end
  end

  # Traduce una dirección y posición en nuevas coordenadas.
  def dir_to_pos(row, col, direction)
    new_coordinates = [row, col]
    #no hay swich en ruby hay case y when
    case direction
    when :UP
      new_coordinates[0] -= 1 if pos_ok(row - 1, col)
    when :DOWN
      new_coordinates[0] += 1 if pos_ok(row + 1, col)
    when :LEFT
      new_coordinates[1] -= 1 if pos_ok(row, col - 1)
    when :RIGHT
      new_coordinates[1] += 1 if pos_ok(row, col + 1)
    end

    new_coordinates
  end

  # Comprueba si una posición en el laberinto está vacía.
  def empty_pos(row, col)
    @labyrinth[row][col] == EMPTY_CHAR
  end

  # Obtiene una posición vacía aleatoria en el laberinto.
  def random_empty_pos
    pos = [rand(@nRows), rand(@nCols)]

    while @labyrinth[pos[0]][pos[1]] != EMPTY_CHAR
      pos = [rand(@nRows), rand(@nCols)]
    end

    pos
  end

  # Comprueba si una fila y columna están dentro de los límites del laberinto.
  def pos_ok(row, col)
    (row >= 0 && row < @nRows) && (col >= 0 && col < @nCols)
  end

  # Coloca un jugador en una posición bidimensional en el laberinto.
  def putPlayer2D()
    raise NotImplementedError, "Subclasses must implement the 'putPlayer2D' method."
  end





end
