/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package irrgarten;

/**
 * Clase que representa un escudo en el juego.
 *
 * @author jesus
 */
public class Shield {
    private float protection;
    private int uses;

    /**
     * Constructor de la clase Shield.
     *
     * @param protection Valor de protección del escudo.
     * @param uses Número de usos disponibles para el escudo.
     */
    public Shield(float protection, int uses) {
        this.protection = protection;
        this.uses = uses;
    }

    /**
     * Constructor de la clase Shield que asigna valores predeterminados.
     */
    public Shield() {
        this.protection = 5.0f;
        this.uses = 3;
    }

    /**
     * Protege al jugador utilizando el escudo.
     *
     * @return Valor de protección proporcionado por el escudo.
     */
    public float protect() {
        float aux = 0.0f;
        if (uses > 0) {
            uses -= 1;
            aux = protection;
        }
        return aux;
    }

    /**
     * Obtiene una representación en cadena del escudo.
     *
     * @return Cadena que representa el escudo.
     */
    @Override
    public String toString() {
        return "S[" + protection + "," + uses + "]";
    }

    /**
     * Determina si el escudo debe descartarse.
     *
     * @return `true` si el escudo debe descartarse, `false` en caso contrario.
     */
    public boolean discard() {
        boolean discard = false;
        Dice dado = new Dice();
        if (dado.discardElement(uses)) {
            discard = true;
        }
        return discard;
    }
}
