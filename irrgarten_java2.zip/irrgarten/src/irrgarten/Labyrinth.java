/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package irrgarten;
import java.util.ArrayList;

/**
 * Clase que representa un laberinto en el juego.
 *
 * @author jesus
 */
public class Labyrinth {
    private static char BLOCK_CHAR = 'X'; 
    private static char EMPTY_CHAR = '-';
    private static char MONSTER_CHAR = 'M';
    private static char COMBAT_CHAR = 'C';
    private static char EXIT_CHAR = 'E';
    private static int ROW = 0;
    private static int COL = 1;
    private int nRows;
    private int nCols;
    private int exitRow;
    private int exitCol;
    //private PlayerSquare player;
    private Monster[][]monsters;
    private Player[][]players;
    private char[][]labyrinth;
   
/**
 * Constructor de la clase Labyrinth.
 *
 * @param nRows   Número de filas del laberinto.
 * @param nCols   Número de columnas del laberinto.
 * @param exitRow Fila de la salida del laberinto.
 * @param exitCol Columna de la salida del laberinto.
 */
 public Labyrinth (int nRows, int nCols, int exitRow, int exitCol){
     
     this.exitRow = exitRow;
     this.exitCol = exitCol;
     this.nCols = nCols;
     this.nRows = nRows;
     monsters = new Monster [nRows][nCols];
     players = new Player [nRows][nCols];
     labyrinth = new char [nRows][nCols];
     for (int i = 0; i < nRows; i++){
         for(int j = 0; j < nCols; j++){
             labyrinth[i][j] = EMPTY_CHAR;
         
         }
     
     }
     
     
 
 
 
 }   
    
  /**
    * Comprueba si existe un ganador en el laberinto.
    *
    * @return `true` si hay un ganador, `false` en caso contrario.
    */  
  public boolean haveaWinner(){
      boolean winner = false;
      
      if (players[exitRow][exitCol] != null){
      
          winner = true;
      
      }
  
      
      return winner;
  
  }
    /**
     * Obtiene una representación en cadena del laberinto.
     *
     * @return Cadena que representa el laberinto.
     */
    @Override
    public String toString() {
        String labe =  "Labyrinth{" + "nRows=" + nRows + ", nCols=" + nCols 
                + ", exitRow=" + exitRow + ", exitCol=" + exitCol + "} \n";
        String rinto = "";
        
        for(int i = 0; i < nRows; i++){
            for(int j = 0; i < nCols; j++){
                rinto += labyrinth[i][j]+" ";
            
            }
            rinto += "\n";
        
        }
        
        return labe+rinto;//laberinto =)
        
    }
  
    /**
     * Agrega un monstruo al laberinto en una posición específica.
     *
     * @param row     Fila en la que se agrega el monstruo.
     * @param col     Columna en la que se agrega el monstruo.
     * @param monster Monstruo a agregar.
     */
    public void addMonster(int row, int col, Monster monster){
    
            //!(monsters[row][col] instanceof Monster tambien sirve asi
            //la segunda condicion
            if (posOK(row,col) && monsters[row][col] == null){
                
                monsters[row][col] = monster;
                labyrinth[row][col]=MONSTER_CHAR;
                
            
            }
    
    
    
    }
    /**
     * Comprueba si una posición en el laberinto contiene un monstruo.
     *
     * @param row Fila de la posición.
     * @param col Columna de la posición.
     * @return `true` si hay un monstruo en la posición, `false` en caso contrario.
     */
    private boolean monsterPos (int row, int col){
        boolean monstruo = false;
        if (labyrinth[row][col] == 'M'){
            
            monstruo = true;
        
        }
        
        return monstruo;
        
    
    }
    /**
     * Comprueba si una posición en el laberinto contiene la salida.
     *
     * @param row Fila de la posición.
     * @param col Columna de la posición.
     * @return `true` si hay una salida en la posición, `false` en caso contrario.
     */
    private boolean exitPos (int row, int col){
        boolean exit = false;
        if (labyrinth[row][col] == 'E'){
            
            exit = true;
        
        }
        
        return exit;
        
    
    }
    /**
     * Comprueba si una posición en el laberinto contiene un combate.
     *
     * @param row Fila de la posición.
     * @param col Columna de la posición.
     * @return `true` si hay un combate en la posición, `false` en caso contrario.
     */
    private boolean combatPos (int row, int col){
        boolean combat = false;
        if (labyrinth[row][col] == 'C'){
            
            combat = true;
        
        }
        
        return combat;
        
    
    }
    /**
     * Comprueba si es posible moverse a una posición en el laberinto.
     *
     * @param row Fila de la posición.
     * @param col Columna de la posición.
     * @return `true` si es posible moverse a la posición, `false` en caso contrario.
     */
    private boolean canStepOn (int row, int col){
        boolean can = false;
        if (posOK(row,col) && (monsterPos(row,col)||emptyPos(row,col)||exitPos(row,col) )){
        
            can = true;
        }
    
        return can;
    }
    /**
     * Actualiza la posición anterior del jugador o monstruo en el laberinto.
     *
     * @param row Fila de la posición anterior.
     * @param col Columna de la posición anterior.
     */
    private void updateOldPos (int row, int col){
        
        if (posOK(row,col)){
            if (combatPos(row,col)){
                labyrinth[row][col] = 'M';
            
            }else{
            
                labyrinth[row][col] = EMPTY_CHAR;
            }
            
        }
        
    
    
    }
    /**
     * Convierte una dirección y posición dadas en nuevas coordenadas.
     *
     * @param row        Fila de la posición actual.
     * @param col        Columna de la posición actual.
     * @param direction  Dirección del movimiento.
     * @return Arreglo de dos enteros que representa las nuevas coordenadas.
     */
    private int[] dir2Pos(int row, int col, Directions direction){
        // Crear una copia de las coordenadas actuales
    int[] coordenadas = {row, col};

    // Calcular la nueva posición según la dirección
    switch (direction) {
        case UP:
            if (posOK(row - 1, col)) {
                coordenadas[0] = row - 1;
            }
            break;
        case DOWN:
            if (posOK(row + 1, col)) {
                coordenadas[0] = row + 1;
            }
            break;
        case LEFT:
            if (posOK(row, col - 1)) {
                coordenadas[1] = col - 1;
            }
            break;
        case RIGHT:
            if (posOK(row, col + 1)) {
                coordenadas[1] = col + 1;
            }
            break;
    }
    
    return coordenadas;
    
    }
    /**
     * Comprueba si una posición en el laberinto está vacía.
     *
     * @param row Fila de la posición.
     * @param col Columna de la posición.
     * @return `true` si la posición está vacía, `false` en caso contrario.
     */

    private boolean emptyPos(int row, int col){
        boolean pos = false;
        if (labyrinth[row][col] == EMPTY_CHAR){
            
            pos = true;
        
        }
        
        return pos;
    
    
    }
    /**
     * Obtiene una posición vacía aleatoria en el laberinto.
     *
     * @return Arreglo de dos enteros que representa una posición vacía aleatoria.
     */
    private int[] randomEmptyPos (){
        int[] pos = {Dice.randomPos(nRows),Dice.randomPos(nCols)};
        while(labyrinth[pos[0]][pos[1]] != EMPTY_CHAR)
        {
            pos = new int[] {Dice.randomPos(nRows),Dice.randomPos(nCols)};    
        }
        
        return pos;
    }
    
    
    /**
     * Comprueba si una fila y columna están dentro de los límites del laberinto.
     *
     * @param row Fila a comprobar.
     * @param col Columna a comprobar.
     * @return `true` si la fila y columna están dentro de los límites, `false` en caso contrario.
     */
    private boolean posOK (int row,int col){
        boolean OK = false;
        if ((row >= 0 && row < nRows) && (col >= 0 && col < nCols)){
            
            OK = true;
        
        }
        
        return OK;
        
        
    
    }
    /**
     * Difunde una lista de jugadores en el laberinto.
     *
     * @param players Lista de jugadores a difundir en el laberinto.
     */
  void spreadPlayers(ArrayList<Player> players){
          throw new UnsupportedOperationException();

  
  }
  /**
   * Coloca un jugador en una dirección específica en el laberinto.
   *
   * @param direction Dirección en la que se coloca al jugador.
   * @param player    Jugador a colocar en el laberinto.
   * @return Monstruo que puede estar presente en la posición.
   */
  
  Monster putPlayer(Directions direction, Player player){
          throw new UnsupportedOperationException();

  
  }
  /**
   * Agrega un bloque al laberinto.
   *
   * @param orientation Orientación del bloque (VERTICAL o HORIZONTAL).
   * @param startRow    Fila de inicio del bloque.
   * @param startCol    Columna de inicio del bloque.
   * @param length      Longitud del bloque.
   */
  void addBlock(Orientation orientation, int startRow,int startCol, int length){
          throw new UnsupportedOperationException();

  
  
  }
  
  /**
   * Obtiene una lista de direcciones válidas para moverse desde una posición dada.
   *
   * @param row Fila de la posición.
   * @param col Columna de la posición.
   * @return Lista de direcciones válidas para moverse.
   */
  
   ArrayList <Directions> validMoves(int row,int col){
        throw new UnsupportedOperationException();

  }
   /**
    * Coloca un jugador en una posición bidimensional en el laberinto.
    *
    * @return Monstruo que puede estar presente en la posición.
    */ 
  private Monster putPlayer2D(){
        throw new UnsupportedOperationException();


  }
}
