/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package irrgarten;

/**
 * Clase que representa el estado actual del juego, incluyendo información sobre el laberinto,
 * los jugadores, los monstruos, el jugador actual, el estado del juego y un registro de eventos.
 *
 * @author jesus
 */
public class GameState {
    private String labyrinthv; // Representa el estado del laberinto.
    private String players; // Representa información sobre los jugadores.
    private String monsters; // Representa información sobre los monstruos.
    private int currentPlayer; // Representa el índice del jugador actual.
    private boolean winner; // Indica si hay un ganador en el juego.
    private String log; // Registra eventos y acciones del juego.

    /**
     * Constructor de la clase GameState.
     *
     * @param labyrinthv     El estado del laberinto.
     * @param players        Información sobre los jugadores.
     * @param monsters       Información sobre los monstruos.
     * @param currentPlayer   El índice del jugador actual.
     * @param winner         Indica si hay un ganador en el juego.
     * @param log            Registra eventos y acciones del juego.
     */
    public GameState(String labyrinthv, String players, String monsters,
                     int currentPlayer, boolean winner, String log) {
        this.labyrinthv = labyrinthv;
        this.players = players;
        this.monsters = monsters;
        this.currentPlayer = currentPlayer;
        this.winner = winner;
        this.log = log;
    }

    /**
     * Obtiene el estado del laberinto.
     *
     * @return El estado del laberinto.
     */
    public String getLabyrinthv() {
        return labyrinthv;
    }

    /**
     * Obtiene información sobre los jugadores.
     *
     * @return Información sobre los jugadores.
     */
    public String getPlayers() {
        return players;
    }

    /**
     * Obtiene información sobre los monstruos.
     *
     * @return Información sobre los monstruos.
     */
    public String getMonsters() {
        return monsters;
    }

    /**
     * Obtiene el índice del jugador actual.
     *
     * @return El índice del jugador actual.
     */
    public int getCurrentPlayer() {
        return currentPlayer;
    }

    /**
     * Verifica si hay un ganador en el juego.
     *
     * @return `true` si hay un ganador, `false` en caso contrario.
     */
    public boolean isWinner() {
        return winner;
    }

    /**
     * Obtiene el registro de eventos y acciones del juego.
     *
     * @return El registro de eventos y acciones del juego.
     */
    public String getLog() {
        return log;
    }
}
