# frozen_string_literal: true
module IRRGARTEN
# Clase Dice representa un conjunto de funciones para simular lanzamientos de dados y generación de valores aleatorios.
class Dice
  # Número máximo de usos de armas y escudos.
  @@MAX_USES = 5
  # Valor máximo para la inteligencia de jugadores y monstruos.
  @@MAX_INTELLIGENCE = 10.0
  # Valor máximo para la fuerza de jugadores y monstruos.
  @@MAX_STRENGTH = 10.0
  # Probabilidad de que un jugador sea resucitado en cada turno.
  @@RESURRECT_PROB = 0.3
  # Número máximo de armas recibidas al ganar un combate.
  @@WEAPONS_REWARD = 2
  # Número máximo de escudos recibidos al ganar un combate.
  @@SHIELDS_REWARD = 3
  # Número máximo de unidades de salud recibidas al ganar un combate.
  @@HEALTH_REWARD = 5
  # Máxima potencia de las armas.
  @@MAX_ATTACK = 3
  # Máxima potencia de los escudos.
  @@MAX_SHIELD = 2

  def self.random_nom
    nombres = ["Garou", "Sukuna", "Kenjaku"]
    nombres.sample
  end

  # Genera un número aleatorio entre 0 y 'max' (no incluido).
  #
  # @param max [Integer] Valor máximo para el número aleatorio.
  # @return [Integer] Número aleatorio.
  def self.random_pos(max)
    Random.rand(max)
  end

  # Determina quién comienza entre los jugadores.
  #
  # @param nplayers [Integer] Número de jugadores.
  # @return [Integer] Índice del jugador que comienza.
  def self.who_starts(nplayers)
    Random.rand(nplayers)
  end

  # Genera un valor de inteligencia aleatorio.
  #
  # @return [Float] Valor de inteligencia aleatorio.
  def self.random_intelligence
    Random.rand * @@MAX_INTELLIGENCE
  end

  # Genera un valor de fuerza aleatorio.
  #
  # @return [Float] Valor de fuerza aleatorio.
  def self.random_strength
    Random.rand * @@MAX_STRENGTH
  end

  # Simula la resurrección de un jugador.
  #
  # @return [Boolean] `true` si el jugador resucita, `false` en caso contrario.
  def self.resurrect_player
    Random.rand(2) == 1
  end

  # Simula la recompensa de armas.
  #
  # @return [Integer] Número de armas recibidas como recompensa.
  def self.weapons_reward
    Random.rand(@@WEAPONS_REWARD + 1)
  end

  # Simula la recompensa de escudos.
  #
  # @return [Integer] Número de escudos recibidos como recompensa.
  def self.shields_reward
    Random.rand(@@SHIELDS_REWARD + 1)
  end

  # Simula la recompensa de unidades de salud.
  #
  # @return [Integer] Número de unidades de salud recibidas como recompensa.
  def self.health_reward
    Random.rand(@@HEALTH_REWARD + 1)
  end

  # Genera una potencia de arma aleatoria.
  #
  # @return [Float] Potencia de arma aleatoria.
  def self.weapon_power
    Random.rand() * @@MAX_ATTACK
  end

  # Genera una potencia de escudo aleatoria.
  #
  # @return [Float] Potencia de escudo aleatoria.
  def self.shield_power
    Random.rand() * @@MAX_SHIELD
  end

  # Simula el número de usos restantes de un elemento.
  #
  # @return [Integer] Número de usos restantes.
  def self.uses_left
    Random.rand(@@MAX_USES + 1)
  end

  # Simula la intensidad de una competencia.
  #
  # @param competence [Float] Competencia para el cálculo de intensidad.
  # @return [Float] Intensidad aleatoria.
  def self.intensity(competence)
    Random.rand() * competence
  end

  # Simula si se descarta un elemento.
  #
  # @param uses_left [Integer] Número de usos restantes del elemento.
  # @return [Boolean] `true` si se descarta el elemento, `false` en caso contrario.
  def self.discard_element(uses_left)
    probability = @@MAX_USES - uses_left
    probability > Random.rand(5)
  end

  #nuevo metodo de la practica 4 a documentar y probar 
  def self.nextStep(preference,validMoves,intelligence)

    unless random_intelligence / @@MAX_INTELLIGENCE < intelligence / @@MAX_INTELLIGENCE
      preference = validMoves[random_pos(validMoves.size)]
    end
    return preference
  end

end
end
