# frozen_string_literal: true
module IRRGARTEN
require_relative 'dice'
require_relative 'labyrinth_character'

# Clase Monster representa a un monstruo en el juego.
class Monster < LabyrinthCharacter

  # Salud inicial del monstruo.
  @@INITIAL_HEALTH = 5

  # Inicializa una nueva instancia de la clase Monster.
  #
  # @param name [String] Nombre del monstruo.
  # @param intelligence [Float] Inteligencia del monstruo.
  # @param strength [Float] Fuerza del monstruo.
  def initialize(name, intelligence, strength)

    super(name,intelligence,@@INITIAL_HEALTH,strength)
    # Fila en la que se encuentra el monstruo.
    @row = 0
    # Columna en la que se encuentra el monstruo.
    @col = 0
  end

  # Realiza un ataque, calculando la intensidad del ataque.
  def attack
    puts Dice.intensity(@strength)
  end

  # Convierte el objeto Monster en una cadena de texto representativa.
  def tostring
    "M[#{@name}, #{@health}, #{@strength}, #{@intelligence}]\n"
  end

  # Defiende al monstruo contra un ataque recibido.
  #
  # @param received_attack [Float] Valor del ataque recibido.
  def defend(received_attack)
     isDead = dead
    if (!isDead)
       defensiveEnergy = Dice.intensity(@intelligence)
    if (defensiveEnergy < received_attack)
      get_wounded
      isDead = dead
    end

    end

    return isDead
  end
end
end
