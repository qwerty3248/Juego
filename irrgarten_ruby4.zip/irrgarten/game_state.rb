# frozen_string_literal: true
module IRRGARTEN
# Clase GameState representa el estado actual del juego.
class GameState
  # Inicializa un nuevo objeto GameState con los parámetros proporcionados.
  #
  # @param labyrinthv [String] Laberinto en forma de cadena.
  # @param players [String] Jugadores en forma de cadena.
  # @param monsters [String] Monstruos en forma de cadena.
  # @param currentplayer [Integer] Índice del jugador actual.
  # @param winner [Boolean] `true` si hay un ganador, `false` en caso contrario.
  # @param log [String] Registro del juego en forma de cadena.
  def initialize(labyrinthv, players, monsters, currentplayer, winner, log)
    @labyrinthv = labyrinthv
    @players = players
    @monsters = monsters
    @currentplayer = currentplayer
    @winner = winner
    @log = log
  end

  # Crea una instancia de GameState con los parámetros proporcionados.
  #
  # @param labyrinthv [String] Laberinto en forma de cadena.
  # @param players [String] Jugadores en forma de cadena.
  # @param monsters [String] Monstruos en forma de cadena.
  # @param currentplayer [Integer] Índice del jugador actual.
  # @param winner [Boolean] `true` si hay un ganador, `false` en caso contrario.
  # @param log [String] Registro del juego en forma de cadena.
  # @return [GameState] Instancia de la clase GameState.
  def self.estado(labyrinthv, players, monsters, currentplayer, winner, log)
    new(labyrinthv, players, monsters, currentplayer, winner, log)
  end

  # Devuelve el índice del jugador actual.
  #
  # @return [Integer] Índice del jugador actual.
  attr_reader :currentplayer

  # Devuelve el laberinto en forma de cadena.
  #
  # @return [String] Laberinto en forma de cadena.
  attr_reader :labyrinthv

  # Devuelve el registro del juego en forma de cadena.
  #
  # @return [String] Registro del juego en forma de cadena.
  attr_reader :log

  # Devuelve `true` si hay un ganador, `false` en caso contrario.
  #
  # @return [Boolean] `true` si hay un ganador, `false` en caso contrario.
  attr_reader :winner

  # Devuelve la representación en forma de cadena de los jugadores.
  #
  # @return [String] Jugadores en forma de cadena.
  attr_reader :players

  # Devuelve la representación en forma de cadena de los monstruos.
  #
  # @return [String] Monstruos en forma de cadena.
  attr_reader :monsters
end
end