# frozen_string_literal: true
module IRRGARTEN
  require_relative 'Dice'
  require_relative 'Player'
class FuzzyPlayer < Player

  def initialize_copy(other)
    super(other)
  end

  def move(direction, valid_moves)
    Dice.nextStep(direction,valid_moves,@intelligence)
  end
  def attack
    ataque = sum_weapons
    ataque + Dice.intensity(@strength)
  end

  def defensive_energy
    defensa = sum_shields
    defensa += Dice.intensity(@intelligence.to_f)
    puts defensa
  end

  def tostring
    "FUZZYPLAYER[#{@name}, #{@health}, #{@strength}, #{@intelligence}]\n"
  end


end
end
