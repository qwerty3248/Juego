# frozen_string_literal: true
module IRRGARTEN
require_relative 'dice'
require_relative 'combat_element'


# Clase Shield representa un escudo con protección y usos limitados.
class Shield < CombatElement
  # Inicializa un nuevo escudo con la protección especificada y la cantidad de usos.
  #
  # @param protection [Float] La protección que proporciona el escudo.
  # @param uses [Integer] La cantidad de usos restantes del escudo.
  def initialize(protection, uses)
    super(protection,uses)
  end

  # Crea una nueva instancia de escudo con valores predeterminados de protección y usos.
  #
  # @param protection [Float] La protección predeterminada del escudo.
  # @param uses [Integer] La cantidad de usos predeterminada del escudo.
  # @return [Shield] Una nueva instancia de escudo.
  def self.proteccion(protection = 5.0, uses = 3)
    new(protection, uses)
  end

  # Obtiene la protección del escudo y reduce un uso si hay disponibles.
  #
  # @return [Float] La protección del escudo o 0.0 si no quedan usos.
  def protect
    if @uses > 0
      @uses -= 1
      aux = @protection
    else
      aux = 0.0
    end
     aux
  end

  # Obtiene una representación en cadena del escudo.
  #
  # @return [String] Una cadena que representa el escudo con su protección y usos restantes.
  def tostring
     "S[#{@protection},#{@uses}]"
  end

  # Verifica si el escudo debe descartarse en función de la probabilidad de descarte.
  #
  # @return [Boolean] `true` si el escudo debe descartarse, `false` en caso contrario.
  def discard
    discard = false
    if Dice.discard_element(@uses)
      discard = true
    end
     discard
  end

  def produceEffect
    protect
  end
end
end
