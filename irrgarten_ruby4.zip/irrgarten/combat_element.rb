# frozen_string_literal: true
module IRRGARTEN
  class CombatElement
    attr_reader :effect, :uses

    def initialize(effect,uses)
      @effect = effect
      @uses = uses

    end

    def produceEffect
      raise NotImplementedError, "#{self.class} debe implementar el método 'produce_effect'"
    end

    def discard
      raise NotImplementedError, "#{self.class} debe implementar el método 'discard'"
    end

    def to_string
      raise NotImplementedError, "#{self.class} debe implementar el método 'to_s'"
    end



  end
end
