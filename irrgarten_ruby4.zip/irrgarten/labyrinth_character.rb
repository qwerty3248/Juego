# frozen_string_literal: true
module IRRGARTEN
  # Clase LabyrinthCharacter
  class LabyrinthCharacter
    attr_accessor :name, :intelligence, :strength, :health, :row, :col

    def initialize(name, intelligence, health, strength)
      @name = name
      @intelligence = intelligence
      @health = health
      @strength = strength
    end

    def initialize_copy(other)
      @name = other.name
      @intelligence = other.intelligence
      @health = other.health
      @strength = other.strength
      @row = other.row
      @col = other.col
    end

    def dead
      @health == 0
    end

    def get_row
      row
    end

    def get_col
      col
    end

    def get_intelligence
      intelligence
    end

    def get_strength
      strength
    end

    def get_name
      name
    end

    def get_health
      health
    end

    def set_health(new_health)
      self.health = new_health
    end

    def set_pos(new_row, new_col)
      self.row = new_row
      self.col = new_col
    end

    def to_string
      raise NotImplementedError, 'Subclasses must implement this method'
    end

    def get_wounded
      self.health -= 1
    end

    def attack
      raise NotImplementedError, 'Subclasses must implement this method'
    end

    def defend(attacks)
      raise NotImplementedError, 'Subclasses must implement this method'
    end
  end

end