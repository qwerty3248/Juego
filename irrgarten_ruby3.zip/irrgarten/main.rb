# frozen_string_literal: true
module MAIN
require_relative 'dice'
require_relative 'weapon'
require_relative 'shield'
require_relative 'orientation'
require_relative 'game_character'
require_relative 'directions'
require_relative 'game_state'
require_relative 'player'
require_relative 'monster'
require_relative 'labyrinth'
require_relative 'game'
require_relative 'controller'
require_relative 'textUI'
include UI
include Control
include IRRGARTEN

text_ui = TextUI.new
#game = Game.new(2, false)
game = Game.new(2, false)
controller = Controller.new(game, text_ui)
controller.play
end







