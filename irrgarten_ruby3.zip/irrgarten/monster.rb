# frozen_string_literal: true
module IRRGARTEN
require_relative 'dice'

# Clase Monster representa a un monstruo en el juego.
class Monster

  # Salud inicial del monstruo.
  @@INITIAL_HEALTH = 5

  # Inicializa una nueva instancia de la clase Monster.
  #
  # @param name [String] Nombre del monstruo.
  # @param intelligence [Float] Inteligencia del monstruo.
  # @param strength [Float] Fuerza del monstruo.
  def initialize(name, intelligence, strength)
    # Nombre del monstruo.
    @name = name
    # Nivel de inteligencia del monstruo.
    @intelligence = intelligence
    # Nivel de fuerza del monstruo.
    @strength = strength
    # Fila en la que se encuentra el monstruo.
    @row = 0
    # Columna en la que se encuentra el monstruo.
    @col = 0
    # Salud del monstruo.
    @health = @@INITIAL_HEALTH
  end

  # Verifica si el monstruo está muerto.
  #
  # @return [Boolean] `true` si el monstruo está muerto, `false` en caso contrario.
  def dead
    @health == 0
  end

  # Realiza un ataque, calculando la intensidad del ataque.
  def attack
    puts Dice.intensity(@strength)
  end

  # Establece la posición del monstruo en el tablero.
  #
  # @param row [Integer] Fila en el tablero.
  # @param col [Integer] Columna en el tablero.
  def set_pos(row, col)
    @row = row
    @col = col
  end

  # Convierte el objeto Monster en una cadena de texto representativa.
  def tostring
    "M[#{@name}, #{@health}, #{@strength}, #{@intelligence}]\n"
  end

  # Reduce la salud del monstruo al recibir un golpe.
  def get_wounded
    @health = @health - 1
  end

  # Defiende al monstruo contra un ataque recibido.
  #
  # @param received_attack [Float] Valor del ataque recibido.
  def defend(received_attack)
     isDead = dead
    if (!isDead)
       defensiveEnergy = Dice.intensity(@intelligence)
    if (defensiveEnergy < received_attack)
      get_wounded
      isDead = dead
    end

    end

    return isDead
  end
end
end
