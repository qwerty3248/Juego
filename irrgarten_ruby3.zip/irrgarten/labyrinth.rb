# frozen_string_literal: true
module IRRGARTEN
require_relative 'player'
require_relative 'monster'
require_relative 'directions'
require_relative 'orientation'
require_relative 'dice'

# Clase que representa un Laberinto.
class Labyrinth
  @@BLOCK_CHAR = 'X'
  @@EMPTY_CHAR = '-'
  @@MONSTER_CHAR = 'M'
  @@COMBAT_CHAR = 'C'
  @@EXIT_CHAR = 'E'
  @@ROW=0
  @@COL=1

  attr_reader :nRows, :nCols, :exitRow, :exitCol, :monsters, :players


  # Constructor de la clase Labyrinth.
  #
  # @param nRows [Integer] Número de filas en el laberinto.
  # @param nCols [Integer] Número de columnas en el laberinto.
  # @param exitRow [Integer] Fila de la salida del laberinto.
  # @param exitCol [Integer] Columna de la salida del laberinto.
  def initialize(nRows, nCols, exitRow, exitCol)
    @nRows = nRows
    @nCols = nCols
    @exitRow = exitRow
    @exitCol = exitCol
    @monsters = Array.new(nRows) { Array.new(nCols) }
    @players = Array.new(nRows) { Array.new(nCols) }
    @labyrinth = Array.new(nRows) { Array.new(nCols, @@EMPTY_CHAR) }
    @labyrinth[exitRow][exitCol] = @@EXIT_CHAR
  end

  # Comprueba si hay un ganador en el laberinto.
  #
  # @return [Boolean] `true` si hay un ganador, `false` en caso contrario.
  def have_winner
    @players[@exitRow][@exitCol] != nil
  end

  # Genera una representación en cadena del laberinto.
  #
  # @return [String] Una cadena que representa el laberinto.
  def to_string
    labe = "Labyrinth{nRows=#{@nRows}, nCols=#{@nCols}, exitRow=#{@exitRow}, exitCol=#{@exitCol}}\n"
    rinto = ""

    for i in 0...@nRows
      for j in 0...@nCols
        rinto += @labyrinth[i][j].to_s + " "
      end
      rinto += "\n"
    end

    labe + rinto
  end


  # Agrega un monstruo al laberinto en una posición específica.
  #
  # @param row [Integer] Fila en la que se agrega el monstruo.
  # @param col [Integer] Columna en la que se agrega el monstruo.
  # @param monster [Monster] Monstruo a agregar.
  def add_monster(row, col, monster)
    if pos_ok(row, col) && @monsters[row][col].nil?
      @monsters[row][col] = monster
      @labyrinth[row][col] = @@MONSTER_CHAR
    end
  end

  # Método de marcador de posición para distribuir jugadores en el laberinto.
  #
  # @param players [Array<Player>] Lista de jugadores para distribuir en el laberinto.
  # @raise [NotImplementedError] Este método debe ser implementado en las subclases.
  def spreadPlayers(players)
    for i in 0...(players.size)

      p = players[i]
    pos = random_empty_pos
    putPlayer2D(-1,-1,pos[@@ROW],pos[@@COL],p)

    end
  end

  # Método de marcador de posición para colocar un jugador en una dirección específica en el laberinto.
  #
  # @param direction [Direction] Dirección en la que se coloca al jugador (:UP, :DOWN, :LEFT, :RIGHT).
  # @param player [Player] Jugador a colocar en el laberinto.
  def putPlayer( direction,  player)
    oldRow = player.row
    oldCol = player.col
    newPos = dir_to_pos(oldRow,oldCol,direction)
    monster = putPlayer2D(oldRow,oldCol,newPos[@@ROW],newPos[@@COL],player)
    monster

  end

  # Método de marcador de posición para agregar un bloque al laberinto.
  #
  # @param orientation [Orientation] Orientación del bloque (:VERTICAL o :HORIZONTAL).
  # @param startRow [Integer] Fila de inicio del bloque.
  # @param startCol [Integer] Columna de inicio del bloque.
  # @param length [Integer] Longitud del bloque.
  # @raise [NotImplementedError] Este método debe ser implementado en las subclases.
  def  addBlock( orientation,  startRow, startCol, length)

    if orientation == Orientation::VERTICAL
      incRow = 1
      incCol = 0
    else
      incRow = 0
      incCol = 1

    end
     row = startRow
     col = startCol

    while pos_ok(row, col) && (empty_pos(row, col) && (length > 0))

      @labyrinth[row][col] = @@BLOCK_CHAR
      length-=1
      row += incRow
      col += incCol
    end
  end

  # Método de marcador de posición para obtener una lista de movimientos válidos desde una posición dada.
  #
  # @param row [Integer] Fila de la posición.
  # @param col [Integer] Columna de la posición.
  # @raise [NotImplementedError] Este método debe ser implementado en las subclases.
  def validMoves( row, col)
    output = Array.new

    if can_step_on(row + 1, col)
      output.push(Directions::DOWN)

      end

    if can_step_on(row - 1, col)
      output.push(Directions::UP)

      end

    if can_step_on(row, col + 1)
      output.push(Directions::RIGHT)

      end

    if can_step_on(row, col - 1)
      output.push(Directions::LEFT)


      end

    output
  end

  private

  # Comprueba si una posición en el laberinto contiene un monstruo.
  def monster_pos(row, col)
    @labyrinth[row][col] == @@MONSTER_CHAR
  end

  # Comprueba si una posición en el laberinto contiene la salida.
  def exit_pos(row, col)
    @labyrinth[row][col] == @@EXIT_CHAR
  end

  # Comprueba si una posición en el laberinto contiene un combate.
  def combat_pos(row, col)
    @labyrinth[row][col] == @@COMBAT_CHAR
  end

  # Comprueba si es posible moverse a una posición en el laberinto.
  def can_step_on(row, col)
    can = false
    if pos_ok(row, col) && (monster_pos(row, col) || empty_pos(row, col) || exit_pos(row, col))

      can = true
    end

    can

  end

  # Actualiza la posición anterior del jugador o monstruo en el laberinto.
  def update_old_pos(row, col)
    if pos_ok(row, col)
      if combat_pos(row, col)
      @labyrinth[row][col] = @@MONSTER_CHAR
      else
      @labyrinth[row][col] = @@EMPTY_CHAR
      end
    end
  end

  # Traduce una dirección y posición en nuevas coordenadas.
  def dir_to_pos(row, col, direction)
    new_coordinates = [row, col]
    #no hay swich en ruby hay case y when
    case direction
    when :UP
      if pos_ok(row - 1, col)
       new_coordinates[0] -= 1
      end
    when :DOWN
      if pos_ok(row + 1, col)
       new_coordinates[0] += 1
      end
    when :LEFT
      if pos_ok(row, col - 1)
       new_coordinates[1] -= 1
      end
    when :RIGHT
      if pos_ok(row, col + 1)
       new_coordinates[1] += 1
      end
    else
      #error
    end

    new_coordinates
  end

  # Comprueba si una posición en el laberinto está vacía.
  def empty_pos(row, col)
    @labyrinth[row][col] == @@EMPTY_CHAR
  end

  # Obtiene una posición vacía aleatoria en el laberinto.
  def random_empty_pos
    pos = [Dice.random_pos(@nRows), Dice.random_pos(@nCols)]

    while @labyrinth[pos[0]][pos[1]] != @@EMPTY_CHAR
      pos = [Dice.random_pos(@nRows), Dice.random_pos(@nCols)]
    end

    pos
  end

  # Comprueba si una fila y columna están dentro de los límites del laberinto.
  def pos_ok(row, col)

    ok = false

    if (row >= 0 && row < nRows) && (col >= 0 && col < nCols)

      ok = true

    end
    ok
  end
  # Coloca un jugador en una posición bidimensional en el laberinto.
  def putPlayer2D(oldRow,oldCol,row,col,player)
    output = nil
    if can_step_on(row, col)
      if pos_ok(oldRow, oldCol)
        p = @players[oldRow][oldCol]
        if p == player
          update_old_pos(oldRow,oldCol)
          @players[oldRow][oldCol] = nil
        end
      end
       monsterPos = monster_pos(row,col)

      if monsterPos
        @labyrinth[row][col] = @@COMBAT_CHAR
        output = @monsters[row][col]

      else

        number = player.number
        @labyrinth[row][col] = number
      end
      @players[row][col] = player
      player.set_pos(row, col)
    end

    output
  end





end

end
