# frozen_string_literal: true
module IRRGARTEN
require_relative 'dice'
# Clase Weapon representa un arma con potencia y usos limitados.
class Weapon
  # Inicializa una nueva arma con la potencia especificada y la cantidad de usos.
  #
  # @param power [Float] La potencia del arma.
  # @param uses [Integer] La cantidad de usos restantes del arma.
  def initialize(power, uses)
    @power = power
    @uses = uses
  end

  # Crea una nueva instancia de arma con valores predeterminados de potencia y usos.
  #
  # @param power [Float] La potencia predeterminada del arma.
  # @param uses [Integer] La cantidad de usos predeterminada del arma.
  # @return [Weapon] Una nueva instancia de arma.
  def self.arma(power = 5.0, uses = 3)
    new(power, uses)
  end

  # Realiza un ataque con el arma y reduce un uso si hay disponibles.
  #
  # @return [Float] La potencia del arma en el ataque o 0.0 si no quedan usos.
  def attack
    if @uses > 0
      @uses -= 1
      aux = @power
    else
      aux = 0.0
    end
    aux
  end

  # Obtiene una representación en cadena del arma.
  #
  # @return [String] Una cadena que representa el arma con su potencia y usos restantes.
  def tostring
    "W[#{@power},#{@uses}]"
  end

  # Verifica si el arma debe descartarse en función de la probabilidad de descarte.
  #
  # @return [Boolean] `true` si el arma debe descartarse, `false` en caso contrario.
  def discard
    discard = false
    if Dice.discard_element(@uses)
      discard = true
    end
   discard
  end
end
end