# frozen_string_literal: true
module IRRGARTEN
# Módulo Directions proporciona constantes que representan direcciones en un juego.
module Directions
  # Constante que representa la dirección izquierda.
  LEFT = :LEFT

  # Constante que representa la dirección derecha.
  RIGHT = :RIGHT

  # Constante que representa la dirección hacia arriba.
  UP = :UP

  # Constante que representa la dirección hacia abajo.
  DOWN = :DOWN
end
end
