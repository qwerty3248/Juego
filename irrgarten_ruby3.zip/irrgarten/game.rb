# frozen_string_literal: true
# module IRRGARTEN
module IRRGARTEN
require_relative 'labyrinth'
require_relative 'game_state'
require_relative 'orientation'
require_relative 'game_character'
require_relative 'dice'

# Clase Game representa el juego principal.
class Game

  # Número máximo de rondas en el juego.
  @@MAX_ROUNDS = 10

  # Inicializa una nueva instancia de la clase Game.
  #
  # @param nplayers [Integer] Número de jugadores.
  def initialize(nplayers,debug)
    if debug
      @players = Array.new(nplayers)
      for i in 0..(nplayers - 1)
        @players[i] = Player.new((i + 1), Dice.random_intelligence, Dice.random_strength)
      end
      @current_player_index = Dice.who_starts(nplayers - 1)
      @monsters = Array.new(nplayers / 2)
      @labyrinth = Labyrinth.new(6, 6, 5, 5)
      @log = ""
      @current_player = @players[@current_player_index]
      configure_labyrinth_debug

    else
      @players = Array.new(nplayers)
      for i in 0..(nplayers - 1)
        @players[i] = Player.new((i + 1), Dice.random_intelligence, Dice.random_strength)
      end
      @current_player_index = Dice.who_starts(nplayers - 1)
      @monsters = Array.new(nplayers / 2)
      @labyrinth = Labyrinth.new(6, 6, 5, 5)
      @log = ""
      @current_player = @players[@current_player_index]
      configure_labyrinth
    end

  end

  # Verifica si el juego ha terminado.
  #
  # @return [Boolean] `true` si el laberinto tiene un ganador, `false` en caso contrario.
  def finished
    @labyrinth.have_winner
  end

  # Obtiene el estado actual del juego.
  def game_state
    jugadores = ""
    monstruos = ""
    for i in 0..(@players.size - 1)
      jugadores += @players[i].tostring
    end
    for i in 0..(@monsters.size - 1)
      monstruos += @monsters[i].tostring
    end

    GameState.estado(@labyrinth.to_string, jugadores, monstruos, @current_player_index, finished, @log)

  end

  # Configura el laberinto con monstruos y bloques.
  def configure_labyrinth
    for i in 0..(@monsters.size - 1)
      @monsters[i] = Monster.new(Dice.random_nom, Dice.random_intelligence, Dice.random_strength)
      @labyrinth.add_monster(Dice.random_pos(6), Dice.random_pos(6), @monsters[i])
    end
    @labyrinth.addBlock(Orientation::VERTICAL, Dice.random_pos(6), Dice.random_pos(6), Dice.random_pos(5))
  end

  def configure_labyrinth_debug
    @monsters[0] =  Monster.new("PEDRO", 1.0, 1.0)

    @labyrinth.add_monster(2, 2, @monsters[0])
    @labyrinth.addBlock(Orientation::VERTICAL, Dice.random_pos(6), Dice.random_pos(6), 5)

  end
  # Cambia al siguiente jugador en turno.
  def next_player
    @current_player_index += 1
    if @current_player_index >= @players.size
      @current_player_index = 0
    end
    @current_player = @players[@current_player_index]
  end

  # Registra al jugador ganador en el registro de juego.
  def log_player_won
    aux = @current_player_index + 1
    @log += "El jugador #{aux} ha ganado el combate\n"
  end

  # Registra al monstruo ganador en el registro de juego.
  def log_monster_won
    @log += "El monstruo #{@monsters[0].tostring} ha ganado el combate\n"
    # No sabemos cuál
  end

  # Registra al jugador resucitado en el registro de juego.
  def log_resurrected
    aux = @current_player_index + 1
    @log += "El jugador #{aux} ha resucitado\n"
  end

  # Registra al jugador que perdió el turno por estar muerto en el registro de juego.
  def log_player_skip_turn
    aux = @current_player_index + 1
    @log += "El jugador #{aux} ha perdido el turno por estar muerto\n"
  end

  # Registra al jugador que no siguió las instrucciones en el registro de juego.
  def log_player_no_orders
    aux = @current_player_index + 1
    @log += "El jugador #{aux} no ha seguido las instrucciones, tonto\n"
  end

  # Registra al jugador que se movió a una casilla sin nada o no pudo moverse en el registro de juego.
  def log_no_monster
    aux = @current_player_index + 1
    @log += "El jugador #{aux} se ha movido a una casilla sin nada o no se ha podido mover, tonto\n"
  end

  # Registra el número de rondas que han transcurrido en el registro de juego.
  #
  # @param rounds [Integer] Número de rondas transcurridas.
  # @param max [Integer] Número máximo de rondas en el juego.
  def log_rounds(rounds, max)
    @log += "Han pasado #{rounds} rondas de #{max}\n"
  end

  # Realiza el siguiente paso en el juego.
  #
  # @param preferred_direction [Directions] Dirección preferida para el movimiento.
  def next_step(preferred_direction)
    @log = ""
    dead = @current_player.dead
    if !dead

      direction = actual_direction(preferred_direction)
    if direction != preferred_direction
      log_player_no_orders

    end
    monster = @labyrinth.putPlayer(direction, @current_player)


    if monster == nil
      log_no_monster

    else
      winner = combat(monster)
      manage_reward(winner)

    end

    else

      manage_resurrection

    end

    endGame = finished

    unless endGame

      next_player

    end
     endGame
  end

  # Obtiene la dirección actual del jugador.
  #
  # @param preferred_direction [Directions] Dirección preferida del jugador.
  # @return [Directions] La dirección actual del jugador.
  def actual_direction(preferred_direction)
    currentRow = @players[@current_player_index].row #hacer un get de row y de col tambien sirve
    currentCol = @players[@current_player_index].col

    validmoves = @labyrinth.validMoves(currentRow, currentCol)

    @current_player.move(preferred_direction, validmoves)

  end

  # Realiza un combate con un monstruo.
  #
  # @param monster [Monster] Monstruo con el que se realiza el combate.
  # @return [GameCharacter] El personaje que ganó el combate.
  def combat(monster)
    rounds = 0
    winner = GameCharacter::PLAYER

     playerAttack=@current_player.attack

     lose = monster.defend(playerAttack)

    while (!lose) && rounds < @@MAX_ROUNDS
      winner = GameCharacter::MONSTER
      rounds += 1
     monsterAttack = monster.attack
    lose = @current_player.defend(monsterAttack)
    if(!lose)
      playerAttack = @current_player.attack
    winner = GameCharacter::PLAYER
    lose = monster.defend(playerAttack)

      end


      end

    log_rounds(rounds,@@MAX_ROUNDS)
    return winner
  end

  # Gestiona las recompensas del juego para el personaje ganador.
  #
  # @param winner [GameCharacter] El personaje ganador del juego.
  def manage_reward(winner)
    if winner == GameCharacter::PLAYER
      @current_player.receive_reward
    log_player_won


    else

      log_monster_won

    end
  end

  # Gestiona la resurrección de los personajes en el juego.
  def manage_resurrection
    resurrect = Dice.resurrect_player
    if resurrect
      @current_player.resurrect
      log_resurrected

    else
      log_player_skip_turn

      end
  end
end
end
