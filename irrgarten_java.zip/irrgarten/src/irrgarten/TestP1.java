/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package irrgarten;

/**
 *
 * @author jesus
 */
public class TestP1 {
    public static void main(String[] args) {
        // TODO code application logic here
        
        String lab = "- - - \n"
                + "- - - \n"
                + "- - - ";
        String players = "2", monster = "1", log = "0";
        
        GameState juego = new GameState(lab,players,monster,1,false,log);
    
        System.out.println(juego.getLabyrinthv());
        
        Dice dado = new Dice();
        
        System.out.println(dado.discardElement(0));
        
        Shield escudo = new Shield(5.0f,3);
        
        System.out.println(escudo.protect());
        
        Weapon arma = new Weapon(22.0f,1);
        
        System.out.println(arma.attack());  
        
        GameCharacter jugador = GameCharacter.MONSTER;
        
        System.out.println(jugador);
        
        Orientation orientacion = Orientation.VERTICAL;
        
        System.out.println(orientacion);
        
        
        Directions direccion =  Directions.UP;
        
        System.out.println(direccion);
                
    }
}
