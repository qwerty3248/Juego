/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package irrgarten;

/**
 *
 * @author jesus
 */
public class Shield {
    private float protection;
    private int uses;

    public Shield(float protection, int uses) {
        this.protection = protection;
        this.uses = uses;
    }

    public Shield() {
        this.protection = 5.0f;
        this.uses = 3;
    }
    
    
    public float protect(){
        
        float aux = 0.0f;
        if(uses > 0){
            uses -= 1;
            aux = protection;
        }
        return aux;
        
    }
    
    @Override
    public String toString() {
        return "S["+ protection + "," + uses + "]";
    }
    
    public boolean discard(){
        boolean discard = false;
        Dice dado = new Dice();
        if (dado.discardElement(uses)){
            discard = true;
        
        }
        return discard;
    
        
    }
}
