/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package irrgarten;
import java.util.Random;
/**
 *
 * @author jesus
 */
public class Dice {
    private static int MAX_USES = 5; //(número máximo de usos de armas y escudos)
    private static float MAX_INTELLIGENCE = 10.0f; //(valor máximo para la inteligencia de jugadores y monstruos)
    private static float MAX_STRENGTH = 10.0f; //(valor máximo para la fuerza de jugadores y monstruos)
    private static float RESURRECT_PROB = 0.3f; //(probabilidad de que un jugador sea resucitado en cada turno)
    private static int WEAPONS_REWARD = 2; //(numero máximo de armas recibidas al ganar un combate)
    private static int SHIELDS_REWARD = 3; //(numero máximo de escudos recibidos al ganar un combate)
    private static int HEALTH_REWARD = 5; //(numero máximo de unidades de salud recibidas al ganar un combate)
    private static int MAX_ATTACK = 3; //(máxima potencia de las armas)
    private static int MAX_SHIELD = 2; //(máxima potencia de los escudos)
    
    private int generator(int min,int max) {
        Random generador = new Random();
        return generador.nextInt((max-min+1)+ min);

    }
    private float generator(float min,float max) {
        Random generador = new Random();
        float aleatorio = generador.nextFloat();
        return  min + aleatorio * (max - min);    

    }
    
    private boolean generator() {
        Random generador = new Random();
        boolean aleatorio = generador.nextBoolean();
        return  aleatorio;    

    }
    
    
    public int randomPos (int max){
        return generator(0,max-1);
    } 
    
    public int WhoStarts (int nplayers){
        return generator(0,nplayers-1); 
    
    }
    
    public float randomIntelligence(){
        return generator (0.0f,MAX_INTELLIGENCE);
    
    }
    
    public float randomStrength(){
        return generator (0.0f,MAX_STRENGTH);
    
    }
    
    public boolean resurrectPlayer(){
        return generator();
    }
    
    public int weaponsReward (){
        return generator(0,WEAPONS_REWARD);
    } 
    
    public int shieldsReward (){
        return generator(0,SHIELDS_REWARD);
    } 
    
    public int healthReward (){
        return generator(0,HEALTH_REWARD);
    }
    
    public float weaponPower(){
        return generator (0.0f,MAX_ATTACK);
    
    }
    
    public float shieldPower(){
        return generator (0.0f,MAX_SHIELD);
    
    }
    
    public int usesLeft (){
        return generator(0,MAX_USES);
    }
    
    public float intensity(float competence){
        return generator (0,competence-1);
    
    }
    
    public boolean discardElement(int usesLeft){
        boolean discard = false;
        int probabilidad = MAX_USES-usesLeft;
        if(probabilidad > generator(0,5)){
            //cuando usesLeft vale a 0 el codigo alguna vez da false
            discard = true;
        }
        return discard;
    }
}
