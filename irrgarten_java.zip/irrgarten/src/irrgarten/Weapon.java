/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package irrgarten;

/**
 *
 * @author jesus
 */
public class Weapon {
    private float power;
    private int uses;

    public Weapon(float power, int uses) {
        this.power = power;
        this.uses = uses;
    }

    public Weapon() {
        this.power = 5.0f;
        this.uses = 3;
    }
    
    
    public float attack(){
        
        float aux = 0.0f;
        if(uses > 0){
            uses -= 1;
            aux = power;
        }
        return aux;
        
    }
    
    @Override
    public String toString() {
        return "W["+ power + "," + uses + "]";
    }
    
    public boolean discard(){
        boolean discard = false;
        Dice dado = new Dice();
        if (dado.discardElement(uses)){
            discard = true;
        
        }
        return discard;
    
        
    }
}
