/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package irrgarten;

/**
 * Enumeración que representa la orientación de elementos en el laberinto, como bloques verticales u horizontales.
 *
 * @author jesus
 */
public enum Orientation {
    VERTICAL, // Elemento con orientación vertical
    HORIZONTAL // Elemento con orientación horizontal
}

