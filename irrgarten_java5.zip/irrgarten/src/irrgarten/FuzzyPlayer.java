/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package irrgarten;

import java.util.ArrayList;

/**
 *
 * @author jesus
 */
public class FuzzyPlayer extends Player {
    
    public FuzzyPlayer (Player other){
        super(other);
    
    }
    
    @Override
    Directions move(Directions direction, ArrayList<Directions> validMoves) {
        //throw new UnsupportedOperationException();
        return Dice.nextStep(direction, validMoves, this.getIntelligence());
        
    }
    
    @Override
    public float attack() {
        float ataque = sumWeapons();
        ataque += Dice.intensity(this.getStrength());
        return ataque;
    }
    
    
    @Override
    float defensiveEnergy() {
        float defensa = sumShields();
        defensa += Dice.intensity(getIntelligence());
        return defensa;
    }
    
    @Override
    public String toString() {
        return "FUZZYPLAYER[" + this.getNumber() + "," + this.getHealth() + "," + this.getStrength() + "," + this.getIntelligence() + "]\n";
    }
    
    
    
}
