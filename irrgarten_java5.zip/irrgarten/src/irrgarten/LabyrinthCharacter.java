/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package irrgarten;

/**
 *
 * @author jesus
 */
public abstract class LabyrinthCharacter {
    private String name;
    private float intelligence;
    private float strength;
    private float  health;
    private int row;
    private int col;
    
    public LabyrinthCharacter(String name,float intelligence,float health, 
                              float strength){
        this.name = name;
        this.intelligence = intelligence;
        this.health = health;
        this.strength = strength;
    
    }
    
    public LabyrinthCharacter(LabyrinthCharacter other){
        this.name = other.name;
        this.intelligence = other.intelligence;
        this.health = other.health;
        this.strength = other.strength;
        this.row = other.row;
        this.col = other.col;
    }
    
    public boolean dead(){
        return (this.health == 0.0f);
        
    }
    public int getRow(){
        return this.row;
    }
    public int getCol(){
        return this.col;
    }
    float getIntelligence(){
        return this.intelligence;
    }
    float getStrength (){
        return this.strength;
    }
    String getName(){
        return this.name;
    }
    float getHealth(){
        return this.health;
    }
    void setHealth(float health){
        this.health = health;
    }
    public void setPos (int row,int col){
        this.row = row;
        this.col = col;
    }

    @Override
    public abstract String toString();
    
    void gotWounded(){
        this.health = this.health - 1;
    }
    
    public abstract float attack();
    
    public abstract boolean defend(float attacks);
    
    
    
    
    
}
