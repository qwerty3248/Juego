/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package irrgarten;

import java.util.List;

public class WeaponCardDeck extends CardDeck<Weapon> {

    @Override
    void addCards(List<Weapon> weapons) {
        addCards(weapons);
    }
}    
