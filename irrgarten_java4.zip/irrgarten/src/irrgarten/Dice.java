/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package irrgarten;

import java.util.Random;
import java.util.ArrayList;

/**
 * La clase `Dice` representa un conjunto de funciones relacionadas con la generación de valores aleatorios.
 * Puede utilizarse para simular eventos aleatorios en un juego o aplicación.
 *
 * @author jesus
 */
public class Dice {

    /**
     * Número máximo de usos de armas y escudos.
     */
    private static int MAX_USES = 5;
    
    /**
     * Valor máximo para la inteligencia de jugadores y monstruos.
     */
    private static float MAX_INTELLIGENCE = 10.0f;

    /**
     * Valor máximo para la fuerza de jugadores y monstruos.
     */
    private static float MAX_STRENGTH = 10.0f;

    /**
     * Probabilidad de que un jugador sea resucitado en cada turno.
     */
    private static float RESURRECT_PROB = 0.3f;

    /**
     * Número máximo de armas recibidas al ganar un combate.
     */
    private static int WEAPONS_REWARD = 2;

    /**
     * Número máximo de escudos recibidos al ganar un combate.
     */
    private static int SHIELDS_REWARD = 3;

    /**
     * Número máximo de unidades de salud recibidas al ganar un combate.
     */
    private static int HEALTH_REWARD = 5;

    /**
     * Máxima potencia de las armas.
     */
    private static int MAX_ATTACK = 3;

    /**
     * Máxima potencia de los escudos.
     */
    private static int MAX_SHIELD = 2;

    private static Random generator = new Random();

    /**
     * Genera un nombre aleatorio a partir de una lista predefinida de nombres.
     *
     * @return Un nombre aleatorio.
     */
    public static String randomNom() {
        String[] nombres = {"Garou", "Sukuna", "Kenjaku","Juan","Fercho","Moisex"};
        return nombres[generator.nextInt(nombres.length-1)];
    }

    /**
     * Genera un número aleatorio dentro del rango especificado.
     *
     * @param max El valor máximo para el número aleatorio.
     * @return Un número aleatorio.
     */
    public static int randomPos(int max) {
        return generator.nextInt(max);
    }

    /**
     * Determina aleatoriamente quién comienza en un juego con un número específico de jugadores.
     *
     * @param nplayers El número de jugadores en el juego.
     * @return El índice del jugador que comienza.
     */
    public static int WhoStarts(int nplayers) {
        return generator.nextInt(nplayers);
    }

    /**
     * Genera un valor de inteligencia aleatorio dentro del rango permitido.
     *
     * @return Un valor de inteligencia aleatorio.
     */
    public static float randomIntelligence() {
        return generator.nextFloat() * MAX_INTELLIGENCE;
    }

    /**
     * Genera un valor de fuerza aleatorio dentro del rango permitido.
     *
     * @return Un valor de fuerza aleatorio.
     */
    public static float randomStrength() {
        return generator.nextFloat() * MAX_STRENGTH;
    }

    /**
     * Determina aleatoriamente si un jugador es resucitado en un turno.
     *
     * @return `true` si el jugador es resucitado, `false` en caso contrario.
     */
    public static boolean resurrectPlayer() {
        return generator.nextBoolean();
    }

    /**
     * Genera un número aleatorio de armas recibidas al ganar un combate.
     *
     * @return El número de armas recibidas.
     */
    public static int weaponsReward() {
        return generator.nextInt(WEAPONS_REWARD);
    }

    /**
     * Genera un número aleatorio de escudos recibidos al ganar un combate.
     *
     * @return El número de escudos recibidos.
     */
    public static int shieldsReward() {
        return generator.nextInt(SHIELDS_REWARD);
    }

    /**
     * Genera un número aleatorio de unidades de salud recibidas al ganar un combate.
     *
     * @return El número de unidades de salud recibidas.
     */
    public static int healthReward() {
        return generator.nextInt(HEALTH_REWARD);
    }

    /**
     * Genera un valor de potencia de arma aleatorio dentro del rango permitido.
     *
     * @return Un valor de potencia de arma aleatorio.
     */
    public static float weaponPower() {
        return generator.nextFloat() * MAX_ATTACK;
    }

    /**
     * Genera un valor de potencia de escudo aleatorio dentro del rango permitido.
     *
     * @return Un valor de potencia de escudo aleatorio.
     */
    public static float shieldPower() {
        return generator.nextFloat() * MAX_SHIELD;
    }

    /**
     * Genera un número aleatorio de usos restantes.
     *
     * @return El número de usos restantes.
     */
    public static int usesLeft() {
        return generator.nextInt(MAX_USES);
    }

    /**
     * Genera una intensidad aleatoria basada en la competencia proporcionada.
     *
     * @param competence La competencia utilizada para determinar la intensidad.
     * @return La intensidad generada.
     */
    public static float intensity(float competence) {
        return generator.nextFloat() * competence;
    }

    /**
     * Determina aleatoriamente si un elemento debe ser descartado en función de los usos restantes.
     *
     * @param usesLeft Los usos restantes del elemento.
     * @return `true` si el elemento debe ser descartado, `false` en caso contrario.
     */
    public static boolean discardElement(int usesLeft) {
        boolean discard = false;
        int probabilidad = MAX_USES - usesLeft;
        if (probabilidad > generator.nextInt(5)) {
            // Cuando `usesLeft` es 0, el código a veces devuelve `false`.
            discard = true;
        }
        return discard;
    }
    
    //nueva funcion que comentar y probar de la practica 4
    
    public static Directions nextStep(Directions preference , 
                  ArrayList<Directions> validMoves, float intelligence){
    
    
        
        if (!(randomIntelligence()/MAX_INTELLIGENCE <
              intelligence/MAX_INTELLIGENCE)){
            preference = validMoves.get(randomPos(validMoves.size()));
            
        }
    
    
        return preference;
    
    
    }
    
}
