/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package irrgarten;

/**
 * Clase que representa un monstruo en el juego, con la capacidad de atacar, recibir daño y
 * gestionar su posición y estado.
 *
 * @author jesus
 */
public class Monster extends LabyrinthCharacter{
    private static int INITIAL_HEALTH = 5;
    /**
     * Constructor de la clase Monster que crea un monstruo con el nombre, inteligencia y fuerza
     * especificados.
     *
     * @param name         Nombre del monstruo.
     * @param intelligence Inteligencia del monstruo.
     * @param strength     Fuerza del monstruo.
     */
    public Monster(String name, float intelligence, float strength) {
        super (name,intelligence,INITIAL_HEALTH,strength);
    }

    /**
     * Realiza un ataque, generando una intensidad de ataque basada en la fuerza del monstruo.
     *
     * @return La intensidad del ataque del monstruo.
     */
    @Override
    public float attack() {
        return Dice.intensity(this.getStrength());
    }


    /**
     * Obtiene una representación de cadena del monstruo, que incluye su nombre, salud, fuerza e inteligencia.
     *
     * @return Representación de cadena del monstruo.
     */
    @Override
    public String toString() {
        return "M[" + this.getName() + "," + this.getHealth() + "," + this.getStrength() + "," + this.getIntelligence() + "]\n";
    }


    /**
     * Intenta defenderse de un ataque recibido.
     *
     * @param receivedAttack El valor del ataque recibido.
     * @return `true` si el monstruo se defiende con éxito, `false` en caso contrario.
     */ 
    @Override
    public boolean defend (float receivedAttack){
    
        //throw new UnsupportedOperationException();
        boolean isDead = dead();
        if (!isDead){
            float defensiveEnergy = Dice.intensity(this.getIntelligence());
            if (defensiveEnergy < receivedAttack){
                gotWounded();
                isDead = dead();
            }
        
        }
        
        return isDead;
              
                
    }
    
    
    
}
