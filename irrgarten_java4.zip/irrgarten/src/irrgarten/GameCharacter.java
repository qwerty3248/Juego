/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package irrgarten;

/**
 * Enumeración que representa los personajes del juego.
 * Puede ser PLAYER (jugador) o MONSTER (monstruo).
 *
 * @author jesus
 */
public enum GameCharacter {PLAYER, MONSTER}
