# frozen_string_literal: true
require_relative 'dice'
require_relative 'weapon'
require_relative 'shield'
require_relative 'orientation'
require_relative 'game_character'
require_relative 'directions'
require_relative 'game_state'

lab = "- - -"
players = "2"
monster = "1"
log = "0"

juego = GameState.new(lab,players,monster,1,false,log)

puts juego.labyrinthv
puts juego.log
dado = Dice.new
for x in 0..50
puts dado.resurrect_Player
end
puts dado.discard_Element(5)
puts dado.health_Reward
puts dado.randompos(17)

escudo = Shield.proteccion
puts escudo.tostring
puts escudo.protect

espada = Weapon.arma
puts espada.tostring
puts espada.attack

perdido = Orientation::VERTICAL
puts perdido

arriba = Directions::DOWN
puts arriba

mostro = GameCharacter::PLAYER
puts mostro






