# frozen_string_literal: true

module Orientation
  VERTICAL = "VERTICAL"
  HORIZONTAL = "HORIZONTAL"
end
