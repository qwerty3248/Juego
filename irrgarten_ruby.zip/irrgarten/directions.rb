# frozen_string_literal: true

module Directions
  LEFT="LEFT"
  RIGHT ="RIGHT"
  ARRIBA = "UP"
  DOWN = "DOWN"
end
