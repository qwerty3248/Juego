# frozen_string_literal: true
require_relative 'dice'
class Weapon
  @power
  @uses

  def initialize (power,uses)
    @power = power
    @uses = uses
  end

  def self.arma(power=5.0,uses=3.0)
    new(power,uses)
  end
  def attack
    if @uses > 0
      @uses -= 1
      aux = @power
    else
      aux = 0.0
    end
    puts aux
  end

  def tostring
    puts "W[#{@power},#{@uses}]"
  end

  def discard
    discard = false
    d = Dice.new
    if d.discardElement(@uses)
      discard = true
    end
    puts discard
  end

end
