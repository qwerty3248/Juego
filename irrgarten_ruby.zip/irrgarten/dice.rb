# frozen_string_literal: true

class Dice
 @@MAX_USES = 5 #(número máximo de usos de armas y escudos)
 @@MAX_INTELLIGENCE= 10.0 #(valor máximo para la inteligencia de jugadores y monstruos)
 @@MAX_STRENGTH = 10.0 #(valor máximo para la fuerza de jugadores y monstruos)
 @@RESURRECT_PROB = 0.3 #(probabilidad de que un jugador sea resucitado en cada turno)
 @@WEAPONS_REWARD = 2 #(numero máximo de armas recibidas al ganar un combate)
 @@SHIELDS_REWARD = 3 #(numero máximo de escudos recibidos al ganar un combate)
 @@HEALTH_REWARD = 5 #(numero máximo de unidades de salud recibidas al ganar un combate)
 @@MAX_ATTACK = 3 #(máxima potencia de las armas)
 @@MAX_SHIELD = 2 #(máxima potencia de los escudos)


 def randompos(max)
   Random.rand(max)
 end
 def whostarts(nplayers)
   Random.rand(nplayers-1)
 end
 def randomintelligence
   Random.rand * @@MAX_INTELLIGENCE
 end
 def random_Strength
   Random.rand * @@MAX_STRENGTH
 end
 def resurrect_Player
   Random.rand(2) == 1
 end
 def weapons_Reward
   Random.rand(@@WEAPONS_REWARD)
 end
 def shields_Reward
   Random.rand(@@SHIELDS_REWARD)
 end
 def health_Reward
   Random.rand(@@HEALTH_REWARD)
 end
 def weapon_Power
   Random.rand() * @@MAX_ATTACK
 end
 def shield_Power
   Random.rand() *@@MAX_SHIELD
 end
 def uses_Left
   Random.rand(@@MAX_USES)

 end
 def intensity(competence)
   Random.rand() * competence

 end
 def discard_Element(uses_Left)
   probabilidad = @@MAX_USES - uses_Left
   probabilidad > Random.rand(5)
 end



end
