# frozen_string_literal: true
require_relative 'dice'


class Shield

  def initialize (protection,uses)
    @protection = protection
    @uses = uses
  end

  def self.proteccion(protection=5.0,uses=3.0)
    new(protection,uses)
  end
  def protect
    if @uses > 0
      @uses -= 1
      aux = @protection
    else
      aux = 0.0
    end
    puts aux
  end

  def tostring
    puts "S[#{@protection},#{@uses}]"
  end

  def discard
    discard = false
    d = Dice.new
    if d.discardElement(@uses)
      discard = true
    end
    puts discard
  end

end
