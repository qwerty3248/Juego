# frozen_string_literal: true

module GameCharacter
  PLAYER = "PLAYER"
  MONSTER= "MONSTER"
end
