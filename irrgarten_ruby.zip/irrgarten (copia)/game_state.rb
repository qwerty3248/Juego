# frozen_string_literal: true

class GameState
  @labyrinthv
  @players
  @monsters
  @currentplayer
  @winner
  @log

  def initialize(labyrinthv,players,monsters,currentplayer,winner,log)
    @labyrinthv = labyrinthv
    @players = players
    @monsters = monsters
    @currentplayer = currentplayer
    @winner = winner
    @log = log
  end
  def self.estado(labyrinthv,players,monsters,currentplayer,winner,log)
    new(labyrinthv,players,monsters,currentplayer,winner,log)
  end
  attr_reader :currentplayer
  attr_reader :labyrinthv
  attr_reader :log
  attr_reader :winner
  attr_reader :players
  attr_reader :monsters

end
