# frozen_string_literal: true

class Dice
 @@MAX_USES = 5 #(número máximo de usos de armas y escudos)
 @@MAX_INTELLIGENCE= 10.0 #(valor máximo para la inteligencia de jugadores y monstruos)
 @@MAX_STRENGTH = 10.0 #(valor máximo para la fuerza de jugadores y monstruos)
 @@RESURRECT_PROB = 0.3 #(probabilidad de que un jugador sea resucitado en cada turno)
 @@WEAPONS_REWARD = 2 #(numero máximo de armas recibidas al ganar un combate)
 @@SHIELDS_REWARD = 3 #(numero máximo de escudos recibidos al ganar un combate)
 @@HEALTH_REWARD = 5 #(numero máximo de unidades de salud recibidas al ganar un combate)
 @@MAX_ATTACK = 3 #(máxima potencia de las armas)
 @@MAX_SHIELD = 2 #(máxima potencia de los escudos)

 private

 def generador_int(min,max)
   aux = rand(min..max)
   puts aux
 end
 def generador_float(min,max)
   aux = rand * (max-min)+min
   puts aux
 end
 def generador_bool
   aux = rand(2) == 1
   puts aux
   end
 public
 def randompos(max)
   aux = generador_int(0,max)
   puts aux
 end
 def whostarts(nplayers)
   aux = generador_int(0,nplayers-1)
   puts aux
 end
 def randomintelligence
   aux = generador_float(0.0,@@MAX_INTELLIGENCE)
   puts aux
 end
 def randomStrength
   aux = generador_float(0.0,@@MAX_STRENGTH)
   puts aux
 end
 def resurrectPlayer
   aux = generador_bool
   puts aux
 end
 def weaponsReward
   aux = generador_int(0,@@WEAPONS_REWARD)
   puts aux
 end
 def shieldsReward
   aux = generador_int(0,@@SHIELDS_REWARD)
   puts aux
 end
 def healthReward
   aux = generador_int(0,@@HEALTH_REWARD)
   puts aux
 end
 def weaponPower
   aux = generador_float(0.0,@@MAX_ATTACK)
   puts aux
 end
 def shieldPower
   aux = generador_float(0.0,@@MAX_SHIELD)
   puts aux
 end
 def usesLeft
   aux = generador_int(0,@@MAX_USES)
   puts aux
 end
 def intensity(competence)
   aux = generador_float(0.0, competence)
   puts aux
 end
 def discardElement(usesLeft)
   probabilidad = @@MAX_USES - usesLeft
   discard = probabilidad > generador_int(0, 5)
 puts discard
 end



end
